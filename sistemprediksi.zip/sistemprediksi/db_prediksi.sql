-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2020 at 05:04 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_prediksi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_dataset_angka`
--

CREATE TABLE `tb_dataset_angka` (
  `id_dataset` int(11) NOT NULL,
  `d_suhu` int(11) NOT NULL,
  `d_kadar_air` float NOT NULL,
  `d_curah_hujan` float NOT NULL,
  `d_ph` float NOT NULL,
  `d_topografi` int(11) NOT NULL,
  `id_var` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_dataset_angka`
--

INSERT INTO `tb_dataset_angka` (`id_dataset`, `d_suhu`, `d_kadar_air`, `d_curah_hujan`, `d_ph`, `d_topografi`, `id_var`) VALUES
(2, 28, 61, 27.7, 4.8, 500, 1),
(3, 26, 61, 27.7, 4.8, 400, 1),
(4, 27, 61, 27.7, 4.8, 200, 1),
(5, 27, 61, 27.7, 4.8, 350, 1),
(6, 27, 61, 27.7, 4.8, 500, 1),
(7, 26, 61, 27.7, 4.8, 600, 1),
(8, 27, 61, 27.7, 4.8, 700, 1),
(9, 27, 61, 27.7, 4.8, 750, 1),
(10, 26, 61, 20.7, 4.8, 700, 1),
(11, 26, 61, 27.7, 4.8, 750, 1),
(12, 27, 61, 27.7, 4.8, 950, 1),
(13, 25, 61, 27.7, 4.8, 900, 1),
(14, 28, 61, 27.7, 4.8, 1250, 1),
(15, 22, 61, 27.7, 4.8, 1450, 1),
(16, 26, 61, 27.7, 4.8, 1500, 1),
(17, 26, 61, 27.7, 4.8, 600, 1),
(18, 26, 61, 27.7, 4.8, 550, 1),
(19, 26, 61, 27.7, 4.8, 1150, 1),
(20, 25, 61, 20.7, 4.8, 600, 1),
(21, 21, 61, 27.7, 4.8, 950, 1),
(22, 27, 61, 27.7, 4.8, 900, 1),
(23, 27, 61, 20.7, 4.8, 500, 1),
(24, 25, 61, 20.7, 4.8, 1000, 1),
(25, 22, 61, 27.7, 4.8, 450, 1),
(26, 27, 61, 27.7, 4.8, 600, 1),
(27, 26, 61, 27.7, 4.8, 450, 1),
(28, 23, 61, 27.7, 4.8, 2100, 1),
(29, 25, 61, 27.7, 4.8, 1450, 1),
(30, 24, 61, 27.7, 4.8, 850, 1),
(31, 26, 61, 27.7, 4.8, 900, 1),
(32, 26, 61, 27.7, 4.8, 2200, 1),
(33, 26, 61, 27.7, 4.8, 1800, 1),
(34, 22, 61, 27.7, 4.8, 1800, 1),
(35, 26, 61, 27.7, 4.8, 600, 1),
(36, 25, 61, 27.7, 4.8, 800, 1),
(37, 22, 61, 27.7, 4.8, 1750, 1),
(38, 25, 61, 20.7, 4.8, 1550, 1),
(39, 23, 61, 20.7, 4.8, 1500, 1),
(40, 26, 61, 20.7, 4.8, 500, 1),
(41, 28, 51.6, 27.7, 6.6, 500, 2),
(42, 26, 51.6, 27.7, 6.6, 400, 2),
(43, 27, 51.6, 27.7, 6.6, 200, 2),
(44, 27, 51.6, 27.7, 6.6, 350, 2),
(45, 27, 51.6, 27.7, 6.6, 500, 2),
(46, 26, 51.6, 27.7, 6.6, 600, 2),
(47, 27, 51.6, 27.7, 6.6, 700, 2),
(48, 27, 51.6, 27.7, 6.6, 750, 2),
(49, 26, 51.6, 20.7, 6.6, 700, 2),
(50, 26, 51.6, 27.7, 6.6, 750, 2),
(51, 27, 51.6, 27.7, 6.6, 950, 2),
(52, 25, 51.6, 27.7, 6.6, 900, 2),
(53, 28, 51.6, 27.7, 6.6, 1250, 2),
(54, 22, 51.6, 27.7, 6.6, 1450, 2),
(55, 26, 51.6, 27.7, 6.6, 1500, 2),
(56, 26, 51.6, 27.7, 6.6, 600, 2),
(57, 26, 51.6, 27.7, 6.6, 550, 2),
(58, 26, 51.6, 27.7, 6.6, 1150, 2),
(59, 25, 51.6, 20.7, 6.6, 600, 2),
(60, 21, 51.6, 27.7, 6.6, 950, 2),
(61, 27, 51.6, 27.7, 6.6, 900, 2),
(62, 27, 51.6, 20.7, 6.6, 500, 2),
(63, 25, 51.6, 20.7, 6.6, 1000, 2),
(64, 22, 51.6, 27.7, 6.6, 450, 2),
(65, 27, 51.6, 27.7, 6.6, 600, 2),
(66, 26, 51.6, 27.7, 6.6, 450, 2),
(67, 23, 51.6, 27.7, 6.6, 2100, 2),
(68, 25, 51.6, 27.7, 6.6, 1450, 2),
(69, 24, 51.6, 27.7, 6.6, 850, 2),
(70, 26, 51.6, 27.7, 6.6, 900, 2),
(71, 26, 51.6, 27.7, 6.6, 2200, 2),
(72, 26, 51.6, 27.7, 6.6, 1800, 2),
(73, 22, 51.6, 27.7, 6.6, 1800, 2),
(74, 26, 51.6, 27.7, 6.6, 600, 2),
(75, 25, 51.6, 27.7, 6.6, 800, 2),
(76, 22, 51.6, 27.7, 6.6, 1750, 2),
(77, 25, 51.6, 20.7, 6.6, 1550, 2),
(78, 23, 51.6, 20.7, 6.6, 1500, 2),
(79, 26, 51.6, 20.7, 6.6, 500, 2),
(80, 28, 51, 27.7, 6.3, 500, 3),
(81, 26, 51, 27.7, 6.3, 400, 3),
(82, 27, 51, 27.7, 6.3, 200, 3),
(83, 27, 51, 27.7, 6.3, 350, 3),
(84, 27, 51, 27.7, 6.3, 500, 3),
(85, 26, 51, 27.7, 6.3, 600, 3),
(86, 27, 51, 27.7, 6.3, 700, 3),
(87, 27, 51, 27.7, 6.3, 750, 3),
(88, 26, 51, 20.7, 6.3, 700, 3),
(89, 26, 51, 27.7, 6.3, 750, 3),
(90, 27, 51, 27.7, 6.3, 950, 3),
(91, 25, 51, 27.7, 6.3, 900, 3),
(92, 28, 51, 27.7, 6.3, 1250, 3),
(93, 22, 51, 27.7, 6.3, 1450, 3),
(94, 26, 51, 27.7, 6.3, 1500, 3),
(95, 26, 51, 27.7, 6.3, 600, 3),
(96, 26, 51, 27.7, 6.3, 550, 3),
(97, 26, 51, 27.7, 6.3, 1150, 3),
(98, 25, 51, 20.7, 6.3, 600, 3),
(99, 21, 51, 27.7, 6.3, 950, 3),
(100, 27, 51, 27.7, 6.3, 900, 3),
(101, 27, 51, 20.7, 6.3, 500, 3),
(102, 25, 51, 20.7, 6.3, 1000, 3),
(103, 22, 51, 27.7, 6.3, 450, 3),
(104, 27, 51, 27.7, 6.3, 600, 3),
(105, 26, 51, 27.7, 6.3, 450, 3),
(106, 23, 51, 27.7, 6.3, 2100, 3),
(107, 25, 51, 27.7, 6.3, 1450, 3),
(108, 24, 51, 27.7, 6.3, 850, 3),
(109, 26, 51, 27.7, 6.3, 900, 3),
(110, 26, 51, 27.7, 6.3, 2200, 3),
(111, 26, 51, 27.7, 6.3, 1800, 3),
(112, 22, 51, 27.7, 6.3, 1800, 3),
(113, 26, 51, 27.7, 6.3, 600, 3),
(114, 25, 51, 27.7, 6.3, 800, 3),
(115, 22, 51, 27.7, 6.3, 1750, 3),
(116, 25, 51, 20.7, 6.3, 1550, 3),
(117, 23, 51, 20.7, 6.3, 1500, 3),
(118, 26, 51, 20.7, 6.3, 500, 3),
(119, 28, 53.5, 27.7, 6, 500, 4),
(120, 26, 53.5, 27.7, 6, 400, 4),
(121, 27, 53.5, 27.7, 6, 200, 4),
(122, 27, 53.5, 27.7, 6, 350, 4),
(123, 27, 53.5, 27.7, 6, 750, 4),
(124, 25, 53.5, 27.7, 6, 900, 4),
(125, 28, 53.5, 27.7, 6, 1250, 4),
(126, 22, 53.5, 27.7, 6, 1450, 4),
(127, 26, 53.5, 27.7, 6, 1500, 4),
(128, 26, 53.5, 27.7, 6, 600, 4),
(129, 26, 53.5, 27.7, 6, 550, 4),
(130, 26, 53.5, 27.7, 6, 1150, 4),
(131, 21, 53.5, 27.7, 6, 950, 4),
(132, 27, 53.5, 27.7, 6, 900, 4),
(133, 27, 53.5, 20.7, 6, 500, 4),
(134, 22, 53.5, 27.7, 6, 450, 4),
(135, 27, 53.5, 27.7, 6, 600, 4),
(136, 26, 53.5, 27.7, 6, 450, 4),
(137, 23, 53.5, 27.7, 6, 2100, 4),
(138, 25, 53.5, 27.7, 6, 1450, 4),
(139, 24, 53.5, 27.7, 6, 850, 4),
(140, 26, 53.5, 27.7, 6, 900, 4),
(141, 26, 53.5, 27.7, 6, 2200, 4),
(142, 26, 53.5, 27.7, 6, 1800, 4),
(143, 26, 53.5, 27.7, 6, 600, 4),
(151, 25, 53.5, 27.7, 6, 800, 4),
(152, 22, 53.5, 27.7, 6, 1750, 4),
(153, 25, 53.5, 20.7, 6, 1550, 4),
(154, 26, 53.5, 20.7, 6, 500, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tb_dataset_kategori`
--

CREATE TABLE `tb_dataset_kategori` (
  `id` int(11) NOT NULL,
  `k_suhu` varchar(11) NOT NULL,
  `k_kadar_air` varchar(11) NOT NULL,
  `k_curah_hujan` varchar(11) NOT NULL,
  `k_ph` varchar(11) NOT NULL,
  `k_topografi` varchar(11) NOT NULL,
  `id_var` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_dataset_kategori`
--

INSERT INTO `tb_dataset_kategori` (`id`, `k_suhu`, `k_kadar_air`, `k_curah_hujan`, `k_ph`, `k_topografi`, `id_var`) VALUES
(2, 'Tinggi', 'Tinggi', 'Tinggi', 'Rendah', 'Rendah', 1),
(3, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Rendah', 1),
(4, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Rendah', 1),
(5, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Rendah', 1),
(6, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Rendah', 1),
(7, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(8, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(9, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(10, 'Sedang', 'Tinggi', 'Rendah', 'Rendah', 'Sedang', 1),
(11, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(12, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(13, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(14, 'Tinggi', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(15, 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(16, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(17, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(18, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(19, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(20, 'Sedang', 'Tinggi', 'Rendah', 'Rendah', 'Sedang', 1),
(21, 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(22, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(23, 'Sedang', 'Tinggi', 'Rendah', 'Rendah', 'Rendah', 1),
(24, 'Sedang', 'Tinggi', 'Rendah', 'Rendah', 'Sedang', 1),
(25, 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 'Rendah', 1),
(26, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(27, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Rendah', 1),
(28, 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(29, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(30, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(31, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(32, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(33, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(34, 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(35, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(36, 'Sedang', 'Tinggi', 'Tinggi', 'Rendah', 'Sedang', 1),
(37, 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 'Tinggi', 1),
(38, 'Sedang', 'Tinggi', 'Rendah', 'Rendah', 'Tinggi', 1),
(39, 'Rendah', 'Tinggi', 'Rendah', 'Rendah', 'Tinggi', 1),
(40, 'Sedang', 'Tinggi', 'Rendah', 'Rendah', 'Rendah', 1),
(41, 'Tinggi', 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 2),
(42, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 2),
(43, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 2),
(44, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 2),
(45, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 2),
(46, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(47, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(48, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(49, 'Sedang', 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 2),
(50, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(51, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(52, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(53, 'Tinggi', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(54, 'Rendah', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(55, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(56, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(57, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(58, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(59, 'Sedang', 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 2),
(60, 'Rendah', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(61, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(62, 'Sedang', 'Rendah', 'Rendah', 'Tinggi', 'Rendah', 2),
(63, 'Sedang', 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 2),
(64, 'Rendah', 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 2),
(65, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(66, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Rendah', 2),
(67, 'Rendah', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(68, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(69, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(70, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(71, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(72, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(73, 'Rendah', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(74, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(75, 'Sedang', 'Rendah', 'Tinggi', 'Tinggi', 'Sedang', 2),
(76, 'Rendah', 'Rendah', 'Tinggi', 'Tinggi', 'Tinggi', 2),
(77, 'Sedang', 'Rendah', 'Rendah', 'Tinggi', 'Tinggi', 2),
(78, 'Rendah', 'Rendah', 'Rendah', 'Tinggi', 'Tinggi', 2),
(79, 'Sedang', 'Rendah', 'Rendah', 'Tinggi', 'Rendah', 2),
(80, 'Tinggi', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 3),
(81, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 3),
(82, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 3),
(83, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 3),
(84, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 3),
(85, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(86, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(87, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(88, 'Sedang', 'Rendah', 'Rendah', 'Sedang', 'Sedang', 3),
(89, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(90, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(91, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(92, 'Tinggi', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(93, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(94, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(95, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(96, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(97, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(98, 'Sedang', 'Rendah', 'Rendah', 'Sedang', 'Sedang', 3),
(99, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(100, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(101, 'Sedang', 'Rendah', 'Rendah', 'Sedang', 'Rendah', 3),
(102, 'Sedang', 'Rendah', 'Rendah', 'Sedang', 'Sedang', 3),
(103, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 3),
(104, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(105, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 3),
(106, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(107, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(108, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(109, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(110, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(111, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(112, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(113, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(114, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 3),
(115, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 3),
(116, 'Sedang', 'Rendah', 'Rendah', 'Sedang', 'Tinggi', 3),
(117, 'Rendah', 'Rendah', 'Rendah', 'Sedang', 'Tinggi', 3),
(118, 'Sedang', 'Rendah', 'Rendah', 'Sedang', 'Rendah', 3),
(119, 'Tinggi', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 4),
(120, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 4),
(121, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 4),
(122, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 4),
(123, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(124, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(125, 'Tinggi', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 4),
(126, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 4),
(127, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 4),
(128, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(129, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(130, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 4),
(131, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(132, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(133, 'Sedang', 'Rendah', 'Rendah', 'Sedang', 'Rendah', 4),
(134, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 4),
(135, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(136, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Rendah', 4),
(137, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 4),
(138, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 4),
(139, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(140, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(141, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 4),
(142, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 4),
(143, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(151, 'Sedang', 'Rendah', 'Tinggi', 'Sedang', 'Sedang', 4),
(152, 'Rendah', 'Rendah', 'Tinggi', 'Sedang', 'Tinggi', 4),
(153, 'Sedang', 'Rendah', 'Rendah', 'Sedang', 'Tinggi', 4),
(154, 'Sedang', 'Rendah', 'Rendah', 'Sedang', 'Rendah', 4);

-- --------------------------------------------------------

--
-- Table structure for table `tb_gain`
--

CREATE TABLE `tb_gain` (
  `ID` int(11) NOT NULL,
  `NAMA` varchar(20) NOT NULL,
  `JUMLAH` varchar(255) NOT NULL,
  `DATETIME` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_gain`
--

INSERT INTO `tb_gain` (`ID`, `NAMA`, `JUMLAH`, `DATETIME`) VALUES
(161, 'suhu', '0.00066737151516127', '2020-08-13 09:47:24'),
(162, 'kadar_air', '1', '2020-08-13 09:47:24'),
(163, 'curah_hujan', '0.0052917497805585', '2020-08-13 09:47:24'),
(164, 'ph', '1', '2020-08-13 09:47:24'),
(165, 'topografi', '0.0032453260892243', '2020-08-13 09:47:24');

-- --------------------------------------------------------

--
-- Table structure for table `tb_histori`
--

CREATE TABLE `tb_histori` (
  `id_histori` int(11) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `h_suhu` int(10) NOT NULL,
  `h_kadar_air` float NOT NULL,
  `h_curah_hujan` float NOT NULL,
  `h_pH` int(10) NOT NULL,
  `h_topografi` int(10) NOT NULL,
  `id_var` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_histori`
--

INSERT INTO `tb_histori` (`id_histori`, `nama`, `h_suhu`, `h_kadar_air`, `h_curah_hujan`, `h_pH`, `h_topografi`, `id_var`) VALUES
(12, 'tes', 28, 61, 27.7, 5, 500, 1),
(13, 'tes', 26, 61, 27.7, 5, 400, 1),
(14, 'tes', 27, 61, 27.7, 5, 200, 1),
(15, 'tes', 27, 61, 27.7, 5, 350, 1),
(16, 'tes', 27, 61, 27.7, 5, 500, 1),
(17, 'tes', 26, 61, 27.7, 5, 600, 1),
(18, 'tes', 27, 61, 27.7, 5, 700, 1),
(19, 'tes', 27, 61, 27.7, 5, 750, 1),
(20, 'tes', 26, 61, 20.7, 5, 700, 1),
(21, 'tes', 26, 61, 27.7, 5, 750, 1),
(22, 'tes', 27, 61, 27.7, 5, 950, 1),
(23, 'tes', 25, 61, 27.7, 5, 900, 1),
(24, 'tes', 28, 61, 27.7, 5, 1250, 1),
(25, 'tes', 22, 61, 27.7, 5, 1450, 1),
(26, 'tes', 26, 61, 27.7, 5, 1500, 1),
(27, 'tes', 26, 61, 27.7, 5, 600, 1),
(28, 'tes', 26, 61, 27.7, 5, 550, 1),
(29, 'tes', 26, 61, 27.7, 5, 1150, 1),
(30, 'tes', 25, 61, 20.7, 5, 600, 1),
(31, 'tes', 21, 61, 27.7, 5, 950, 1),
(32, 'tes', 27, 61, 27.7, 5, 900, 1),
(33, 'tes', 27, 61, 20.7, 5, 500, 1),
(34, 'tes', 25, 61, 20.7, 5, 1000, 1),
(35, 'tes', 22, 61, 27.7, 5, 450, 1),
(36, 'tes', 27, 61, 27.7, 5, 600, 1),
(37, 'tes', 26, 61, 27.7, 5, 450, 1),
(38, 'tes', 23, 61, 27.7, 5, 2100, 1),
(39, 'tes', 25, 61, 27.7, 5, 1450, 1),
(40, 'tes', 24, 61, 27.7, 5, 850, 1),
(41, 'tes', 26, 61, 27.7, 5, 900, 1),
(42, 'tes', 26, 61, 27.7, 5, 2200, 1),
(43, 'tes', 26, 61, 27.7, 5, 1800, 1),
(44, 'tes', 22, 61, 27.7, 5, 1800, 1),
(45, 'tes', 26, 61, 27.7, 5, 600, 1),
(46, 'tes', 25, 61, 27.7, 5, 800, 1),
(47, 'tes', 22, 61, 27.7, 5, 1750, 1),
(48, 'tes', 25, 61, 20.7, 5, 1550, 1),
(49, 'tes', 23, 61, 20.7, 5, 1500, 1),
(50, 'tes', 26, 61, 20.7, 5, 500, 1),
(51, 'tes', 28, 51.6, 27.7, 7, 500, 2),
(52, 'tes', 26, 51.6, 27.7, 7, 400, 2),
(53, 'tes', 27, 51.6, 27.7, 7, 200, 2),
(54, 'tes', 27, 51.6, 27.7, 7, 350, 2),
(55, 'tes', 27, 51.6, 27.7, 7, 500, 2),
(56, 'tes', 26, 51.6, 27.7, 7, 600, 2),
(57, 'tes', 27, 51.6, 27.7, 7, 700, 2),
(58, 'tes', 27, 51.6, 27.7, 7, 750, 2),
(59, 'tes', 26, 51.6, 20.7, 7, 700, 2),
(60, 'tes', 26, 51.6, 27.7, 7, 750, 2),
(61, 'tes', 27, 51.6, 27.7, 7, 950, 2),
(62, 'tes', 25, 51.6, 27.7, 7, 900, 2),
(63, 'tes', 28, 51.6, 27.7, 7, 1250, 2),
(64, 'tes', 22, 51.6, 27.7, 7, 1450, 2),
(65, 'tes', 26, 51.6, 27.7, 7, 1500, 2),
(66, 'tes', 26, 51.6, 27.7, 7, 600, 2),
(67, 'tes', 26, 51.6, 27.7, 7, 550, 2),
(68, 'tes', 26, 51.6, 27.7, 7, 1150, 2),
(69, 'tes', 25, 51.6, 20.7, 7, 600, 2),
(70, 'tes', 21, 51.6, 27.7, 7, 950, 2),
(71, 'tes', 27, 51.6, 27.7, 7, 900, 2),
(72, 'tes', 27, 51.6, 20.7, 7, 500, 2),
(73, 'tes', 25, 51.6, 20.7, 7, 1000, 2),
(74, 'tes', 22, 51.6, 27.7, 7, 450, 2),
(75, 'tes', 27, 51.6, 27.7, 7, 600, 2),
(76, 'tes', 26, 51.6, 27.7, 7, 450, 2),
(77, 'tes', 23, 51.6, 27.7, 7, 2100, 2),
(78, 'tes', 25, 51.6, 27.7, 7, 1450, 2),
(79, 'tes', 24, 51.6, 27.7, 7, 850, 2),
(80, 'tes', 26, 51.6, 27.7, 7, 900, 2),
(81, 'tes', 26, 51.6, 27.7, 7, 2200, 2),
(82, 'tes', 26, 51.6, 27.7, 7, 1800, 2),
(83, 'tes', 22, 51.6, 27.7, 7, 1800, 2),
(84, 'tes', 26, 51.6, 27.7, 7, 600, 2),
(85, 'tes', 25, 51.6, 27.7, 7, 800, 2),
(86, 'tes', 22, 51.6, 27.7, 7, 1750, 2),
(87, 'tes', 25, 51.6, 20.7, 7, 1550, 2),
(88, 'tes', 23, 51.6, 20.7, 7, 1500, 2),
(89, 'tes', 26, 51.6, 20.7, 7, 500, 2),
(90, 'tes', 28, 51, 27.7, 6, 500, 3),
(91, 'tes', 26, 51, 27.7, 6, 400, 3),
(92, 'tes', 27, 51, 27.7, 6, 200, 3),
(93, 'tes', 27, 51, 27.7, 6, 350, 3),
(94, 'tes', 27, 51, 27.7, 6, 500, 3),
(95, 'tes', 26, 51, 27.7, 6, 600, 3),
(96, 'tes', 27, 51, 27.7, 6, 700, 3),
(97, 'tes', 27, 51, 27.7, 6, 750, 3),
(98, 'tes', 26, 51, 20.7, 6, 700, 3),
(99, 'tes', 26, 51, 27.7, 6, 750, 3),
(100, 'tes', 27, 51, 27.7, 6, 950, 3),
(101, 'tes', 25, 51, 27.7, 6, 900, 3),
(102, 'tes', 28, 51, 27.7, 6, 1250, 3),
(103, 'tes', 22, 51, 27.7, 6, 1450, 3),
(104, 'tes', 26, 51, 27.7, 6, 1500, 3),
(105, 'tes', 26, 51, 27.7, 6, 600, 3),
(106, 'tes', 26, 51, 27.7, 6, 550, 3),
(107, 'tes', 26, 51, 27.7, 6, 1150, 3),
(108, 'tes', 25, 51, 20.7, 6, 600, 3),
(109, 'tes', 21, 51, 27.7, 6, 950, 3),
(110, 'tes', 27, 51, 27.7, 6, 900, 3),
(111, 'tes', 27, 51, 20.7, 6, 500, 3),
(112, 'tes', 25, 51, 20.7, 6, 1000, 3),
(113, 'tes', 22, 51, 27.7, 6, 450, 3),
(114, 'tes', 27, 51, 27.7, 6, 600, 3),
(115, 'tes', 26, 51, 27.7, 6, 450, 3),
(116, 'tes', 23, 51, 27.7, 6, 2100, 3),
(117, 'tes', 25, 51, 27.7, 6, 1450, 3),
(118, 'tes', 24, 51, 27.7, 6, 850, 3),
(119, 'tes', 26, 51, 27.7, 6, 900, 3),
(120, 'tes', 26, 51, 27.7, 6, 2200, 3),
(121, 'tes', 26, 51, 27.7, 6, 1800, 3),
(122, 'tes', 22, 51, 27.7, 6, 1800, 3),
(123, 'tes', 26, 51, 27.7, 6, 600, 3),
(124, 'tes', 25, 51, 27.7, 6, 800, 3),
(125, 'tes', 22, 51, 27.7, 6, 1750, 3),
(126, 'tes', 25, 51, 20.7, 6, 1550, 3),
(127, 'tes', 23, 51, 20.7, 6, 1500, 3),
(128, 'tes', 26, 51, 20.7, 6, 500, 3),
(129, 'tes', 28, 53.5, 27.7, 6, 500, 3),
(130, 'tes', 26, 53.5, 27.7, 6, 400, 3),
(131, 'tes', 27, 53.5, 27.7, 6, 200, 3),
(132, 'tes', 27, 53.5, 27.7, 6, 350, 3),
(133, 'tes', 27, 53.5, 27.7, 6, 750, 3),
(134, 'tes', 25, 53.5, 27.7, 6, 900, 3),
(135, 'tes', 28, 53.5, 27.7, 6, 1250, 3),
(136, 'tes', 22, 53.5, 27.7, 6, 1450, 3),
(137, 'tes', 26, 53.5, 27.7, 6, 1500, 3),
(138, 'tes', 26, 53.5, 27.7, 6, 600, 3),
(139, 'tes', 26, 53.5, 27.7, 6, 550, 3),
(140, 'tes', 21, 53.5, 27.7, 6, 950, 3),
(141, 'tes', 27, 53.5, 27.7, 6, 900, 3),
(142, 'tes', 27, 53.5, 20.7, 6, 500, 3),
(143, 'tes', 22, 53.5, 27.7, 6, 450, 3),
(144, 'tes', 27, 53.5, 27.7, 6, 600, 3),
(145, 'tes', 26, 53.5, 27.7, 6, 450, 3),
(146, 'tes', 23, 53.5, 27.7, 6, 2100, 3),
(147, 'tes', 25, 53.5, 27.7, 6, 1450, 3),
(148, 'tes', 24, 53.5, 27.7, 6, 850, 3),
(149, 'tes', 26, 53.5, 27.7, 6, 900, 3),
(150, 'tes', 26, 53.5, 27.7, 6, 2200, 3),
(151, 'tes', 26, 53.5, 27.7, 6, 1800, 3),
(152, 'tes', 26, 53.5, 27.7, 6, 600, 3),
(153, 'tes', 25, 53.5, 27.7, 6, 800, 3),
(154, 'tes', 22, 53.5, 27.7, 6, 1750, 3),
(155, 'tes', 25, 53.5, 20.7, 6, 1550, 3),
(156, 'tes', 26, 53.5, 20.7, 6, 500, 3),
(157, 'tes', 26, 53.3, 27.7, 6, 1150, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai_kategori`
--

CREATE TABLE `tb_nilai_kategori` (
  `id_nkategori` int(11) NOT NULL,
  `nama_variabel` varchar(25) NOT NULL,
  `nilai1` float NOT NULL,
  `nilai2` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_nilai_kategori`
--

INSERT INTO `tb_nilai_kategori` (`id_nkategori`, `nama_variabel`, `nilai1`, `nilai2`) VALUES
(1, 'suhu', 23.6, 27.2),
(2, 'kadar air', 55, 0),
(3, 'curah hujan', 20.7, 0),
(4, 'ph', 5.2, 6.6);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`) VALUES
(1, 'alam', '0116'),
(2, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tb_varietas`
--

CREATE TABLE `tb_varietas` (
  `id_var` int(11) NOT NULL,
  `nm_var` varchar(25) NOT NULL,
  `keunggulan` text NOT NULL,
  `kekurangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_varietas`
--

INSERT INTO `tb_varietas` (`id_var`, `nm_var`, `keunggulan`, `kekurangan`) VALUES
(1, 'Ciherang', 'Tahan terhadap wereng coklat biotipe 2 dan agak tahan biotipe 3, agak tahan terhadap hawar daun bakteri strain III dan IV', 'Dapat terkena hawar daun dan wereng jika perawatan tidak maksimal'),
(2, 'IR64', 'Tahan terhadap wereng coklat biotipe 1,2 dan agak tahan terhadap wereng coklat biotipe 3, agak tahan hawar daun bakteri strain IV tahan virus kerdil rumput', 'tidak cocok ditanam di dataran tinggi tanpa irigasi'),
(3, 'Mekongga', 'Agak tahan terhadap wereng coklat biotipe 2 dan 3, Agak Tahan terhadap hawar daun bakteri strain IV', 'Tidak cocok ditanam pada dataran tinggi dan tanpa irigasi, terkadang terkena hawar daun dan wereng jika perawatan lahan kurang baik'),
(4, 'Situ Bagendit', 'Agak tahan terhadap Blast dan Agak tahan terhadap hawar daun strain III dan IV', 'Kurang cocok ditanam pada lahan sawah yang terlalu basah dan kurang tahan terhadap hama wereng');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_dataset_angka`
--
ALTER TABLE `tb_dataset_angka`
  ADD PRIMARY KEY (`id_dataset`),
  ADD KEY `id_var` (`id_var`);

--
-- Indexes for table `tb_dataset_kategori`
--
ALTER TABLE `tb_dataset_kategori`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_var` (`id_var`);

--
-- Indexes for table `tb_gain`
--
ALTER TABLE `tb_gain`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tb_histori`
--
ALTER TABLE `tb_histori`
  ADD PRIMARY KEY (`id_histori`),
  ADD KEY `id_var` (`id_var`);

--
-- Indexes for table `tb_nilai_kategori`
--
ALTER TABLE `tb_nilai_kategori`
  ADD PRIMARY KEY (`id_nkategori`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `tb_varietas`
--
ALTER TABLE `tb_varietas`
  ADD PRIMARY KEY (`id_var`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_dataset_angka`
--
ALTER TABLE `tb_dataset_angka`
  MODIFY `id_dataset` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `tb_dataset_kategori`
--
ALTER TABLE `tb_dataset_kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `tb_gain`
--
ALTER TABLE `tb_gain`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;

--
-- AUTO_INCREMENT for table `tb_histori`
--
ALTER TABLE `tb_histori`
  MODIFY `id_histori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `tb_nilai_kategori`
--
ALTER TABLE `tb_nilai_kategori`
  MODIFY `id_nkategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tb_varietas`
--
ALTER TABLE `tb_varietas`
  MODIFY `id_var` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_dataset_angka`
--
ALTER TABLE `tb_dataset_angka`
  ADD CONSTRAINT `tb_dataset_angka_ibfk_1` FOREIGN KEY (`id_var`) REFERENCES `tb_varietas` (`id_var`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_histori`
--
ALTER TABLE `tb_histori`
  ADD CONSTRAINT `tb_histori_ibfk_1` FOREIGN KEY (`id_var`) REFERENCES `tb_varietas` (`id_var`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
