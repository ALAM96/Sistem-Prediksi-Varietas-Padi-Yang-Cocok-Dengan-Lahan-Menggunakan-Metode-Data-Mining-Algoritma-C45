<?php

defined('BASEPATH') or exit('No direct script access allowed');

class M_prediksi extends CI_Model
{



    public function creatRule()
    {

        function gain1($p, $q, $x1, $x2, $x3, $y1, $y2, $y3)
        {
            return $gain = ($p) - (($x1 / $q) * $y1) - (($x2 / $q) * $y2) - (($x3 / $q) * $y3);
        }

        function gain2($p, $q, $x1, $x2, $y1, $y2)
        {
            return $gain = ($p) - (($x1 / $q) * $y1) - (($x2 / $q) * $y2);
        }

        function entrophy($x, $a, $b, $c, $d)
        {
            return $entrophy = ((-$a / $x) * log($a / $x, 2) + (-$b / $x) * log($b / $x, 2) + (-$c / $x) * log($c / $x, 2) + (-$d / $x) * log($d / $x, 2));
        }

        function toInt($a)
        {
            if ($a == true) {
                $a = 1;
            }
            return $a;
        }


        $dataset = $this->db->get('tb_dataset_kategori')->result_array();
        $jml_dataset = count($dataset);


        $query = "SELECT count(id_var) as id_var FROM tb_dataset_kategori where id_var=1";
        $result = $this->db->query($query);
        $jml_ciherang = $result->row()->id_var;

        $query = "SELECT count(id_var) as id_var FROM tb_dataset_kategori where id_var=2";
        $result = $this->db->query($query);
        $jml_ir64 = $result->row()->id_var;

        $query = "SELECT count(id_var) as id_var FROM tb_dataset_kategori where id_var=3";
        $result = $this->db->query($query);
        $jml_mekongga = $result->row()->id_var;

        $query = "SELECT count(id_var) as id_var FROM tb_dataset_kategori where id_var=4";
        $result = $this->db->query($query);
        $jml_situ_bagendit = $result->row()->id_var;

        $nilai_entrophy = entrophy($jml_dataset, $jml_ciherang, $jml_ir64, $jml_mekongga, $jml_situ_bagendit);

        $query = "SELECT count(k_suhu) as k_suhu, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_suhu = 'Rendah' OR 'rendah')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_suhu = 'Rendah' OR 'rendah')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_suhu = 'Rendah' OR 'rendah')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_suhu = 'Rendah' OR 'rendah')) as bagendit FROM tb_dataset_kategori where k_suhu = 'Rendah' OR 'rendah' ";
        $result = $this->db->query($query);
        $sr_ciherang = $result->row()->ciherang;
        $sr_ir64 = $result->row()->ir64;
        $sr_mekongga = $result->row()->mekongga;
        $sr_bagendit = $result->row()->bagendit;
        $suhu_rendah = $result->row()->k_suhu;

        $query = "SELECT count(k_suhu) as k_suhu, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_suhu = 'Sedang' OR 'sedang')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_suhu = 'Sedang' OR 'sedang')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_suhu = 'Sedang' OR 'sedang')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_suhu = 'Sedang' OR 'sedang')) as bagendit FROM tb_dataset_kategori where k_suhu = 'Sedang' OR 'sedang' ";
        $result = $this->db->query($query);
        $ss_ciherang = $result->row()->ciherang;
        $ss_ir64 = $result->row()->ir64;
        $ss_mekongga = $result->row()->mekongga;
        $ss_bagendit = $result->row()->bagendit;
        $suhu_sedang = $result->row()->k_suhu;

        $query = "SELECT count(k_suhu) as k_suhu, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_suhu = 'Tinggi' OR 'tinggi')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_suhu = 'Tinggi' OR 'tinggi')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_suhu = 'Tinggi' OR 'tinggi')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_suhu = 'Tinggi' OR 'tinggi')) as bagendit FROM tb_dataset_kategori where k_suhu = 'Tinggi' OR 'tinggi' ";
        $result = $this->db->query($query);
        $st_ciherang = $result->row()->ciherang;
        $st_ir64 = $result->row()->ir64;
        $st_mekongga = $result->row()->mekongga;
        $st_bagendit = $result->row()->bagendit;
        $suhu_tinggi = $result->row()->k_suhu;

        $query = "SELECT count(k_kadar_air) as k_kadar_air, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_kadar_air = 'Rendah' OR 'rendah')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_kadar_air = 'Rendah' OR 'rendah')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_kadar_air = 'Rendah' OR 'rendah')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_kadar_air = 'Rendah' OR 'rendah')) as bagendit FROM tb_dataset_kategori where k_kadar_air = 'Rendah' OR 'rendah' ";
        $result = $this->db->query($query);
        $kr_ciherang = $result->row()->ciherang;
        $kr_ir64 = $result->row()->ir64;
        $kr_mekongga = $result->row()->mekongga;
        $kr_bagendit = $result->row()->bagendit;
        $kadar_air_rendah = $result->row()->k_kadar_air;

        $query = "SELECT count(k_kadar_air) as k_kadar_air, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_kadar_air = 'Tinggi' OR 'tinggi')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_kadar_air = 'Tinggi' OR 'tinggi')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_kadar_air = 'Tinggi' OR 'tinggi')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_kadar_air = 'Tinggi' OR 'tinggi')) as bagendit FROM tb_dataset_kategori where k_kadar_air = 'Tinggi' OR 'tinggi' ";
        $result = $this->db->query($query);
        $kt_ciherang = $result->row()->ciherang;
        $kt_ir64 = $result->row()->ir64;
        $kt_mekongga = $result->row()->mekongga;
        $kt_bagendit = $result->row()->bagendit;
        $kadar_air_tinggi = $result->row()->k_kadar_air;

        $query = "SELECT count(k_curah_hujan) as k_curah_hujan, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_curah_hujan = 'Rendah' OR 'rendah')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_curah_hujan = 'Rendah' OR 'rendah')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_curah_hujan = 'Rendah' OR 'rendah')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_curah_hujan = 'Rendah' OR 'rendah')) as bagendit FROM tb_dataset_kategori where k_curah_hujan = 'Rendah' OR 'rendah' ";
        $result = $this->db->query($query);
        $cr_ciherang = $result->row()->ciherang;
        $cr_ir64 = $result->row()->ir64;
        $cr_mekongga = $result->row()->mekongga;
        $cr_bagendit = $result->row()->bagendit;
        $curah_hujan_rendah = $result->row()->k_curah_hujan;

        $query = "SELECT count(k_curah_hujan) as k_curah_hujan, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_curah_hujan = 'Tinggi' OR 'tinggi')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_curah_hujan = 'Tinggi' OR 'tinggi')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_curah_hujan = 'Tinggi' OR 'tinggi')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_curah_hujan = 'Tinggi' OR 'tinggi')) as bagendit FROM tb_dataset_kategori where k_curah_hujan = 'Tinggi' OR 'tinggi' ";
        $result = $this->db->query($query);
        $ct_ciherang = $result->row()->ciherang;
        $ct_ir64 = $result->row()->ir64;
        $ct_mekongga = $result->row()->mekongga;
        $ct_bagendit = $result->row()->bagendit;
        $curah_hujan_tinggi = $result->row()->k_curah_hujan;

        $query = "SELECT count(k_ph) as k_ph, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_ph = 'Rendah' OR 'rendah')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_ph = 'Rendah' OR 'rendah')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_ph = 'Rendah' OR 'rendah')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_ph = 'Rendah' OR 'rendah')) as bagendit FROM tb_dataset_kategori where k_ph = 'Rendah' OR 'rendah' ";
        $result = $this->db->query($query);
        $pr_ciherang = $result->row()->ciherang;
        $pr_ir64 = $result->row()->ir64;
        $pr_mekongga = $result->row()->mekongga;
        $pr_bagendit = $result->row()->bagendit;
        $ph_rendah = $result->row()->k_ph;

        $query = "SELECT count(k_ph) as k_ph, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_ph = 'Sedang' OR 'sedang')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_ph = 'Sedang' OR 'sedang')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_ph = 'Sedang' OR 'sedang')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_ph = 'Sedang' OR 'sedang')) as bagendit FROM tb_dataset_kategori where k_ph = 'Sedang' OR 'sedang' ";
        $result = $this->db->query($query);
        $ps_ciherang = $result->row()->ciherang;
        $ps_ir64 = $result->row()->ir64;
        $ps_mekongga = $result->row()->mekongga;
        $ps_bagendit = $result->row()->bagendit;
        $ph_sedang = $result->row()->k_ph;

        $query = "SELECT count(k_ph) as k_ph, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_ph = 'Tinggi' OR 'tinggi')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_ph = 'Tinggi' OR 'tinggi')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_ph = 'Tinggi' OR 'tinggi')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_ph = 'Tinggi' OR 'tinggi')) as bagendit FROM tb_dataset_kategori where k_ph = 'Tinggi' OR 'tinggi' ";
        $result = $this->db->query($query);
        $pt_ciherang = $result->row()->ciherang;
        $pt_ir64 = $result->row()->ir64;
        $pt_mekongga = $result->row()->mekongga;
        $pt_bagendit = $result->row()->bagendit;
        $ph_tinggi = $result->row()->k_ph;

        $query = "SELECT count(k_topografi) as k_topografi, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_topografi = 'Rendah' OR 'rendah')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_topografi = 'Rendah' OR 'rendah')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_topografi = 'Rendah' OR 'rendah')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_topografi = 'Rendah' OR 'rendah')) as bagendit FROM tb_dataset_kategori where k_topografi = 'Rendah' OR 'rendah' ";
        $result = $this->db->query($query);
        $tr_ciherang = $result->row()->ciherang;
        $tr_ir64 = $result->row()->ir64;
        $tr_mekongga = $result->row()->mekongga;
        $tr_bagendit = $result->row()->bagendit;
        $topografi_rendah = $result->row()->k_topografi;

        $query = "SELECT count(k_topografi) as k_topografi, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_topografi = 'Sedang' OR 'sedang')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_topografi = 'Sedang' OR 'sedang')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_topografi = 'Sedang' OR 'sedang')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_topografi = 'Sedang' OR 'sedang')) as bagendit FROM tb_dataset_kategori where k_topografi = 'Sedang' OR 'sedang' ";
        $result = $this->db->query($query);
        $ts_ciherang = $result->row()->ciherang;
        $ts_ir64 = $result->row()->ir64;
        $ts_mekongga = $result->row()->mekongga;
        $ts_bagendit = $result->row()->bagendit;
        $topografi_sedang = $result->row()->k_topografi;

        $query = "SELECT count(k_topografi) as k_topografi, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=1 AND (k_topografi = 'Tinggi' OR 'tinggi')) as ciherang, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=2 AND (k_topografi = 'Tinggi' OR 'tinggi')) as ir64, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=3 AND (k_topografi = 'Tinggi' OR 'tinggi')) as mekongga, (SELECT count(id_var) FROM tb_dataset_kategori WHERE id_var=4 AND (k_topografi = 'Tinggi' OR 'tinggi')) as bagendit FROM tb_dataset_kategori where k_topografi = 'Tinggi' OR 'tinggi' ";
        $result = $this->db->query($query);
        $tt_ciherang = $result->row()->ciherang;
        $tt_ir64 = $result->row()->ir64;
        $tt_mekongga = $result->row()->mekongga;
        $tt_bagendit = $result->row()->bagendit;
        $topografi_tinggi = $result->row()->k_topografi;


        //((-$jml_ciherang / $jml_dataset) * log($jml_ciherang / $jml_dataset, 2) + (-$jml_ir64 / $jml_dataset) * log($jml_ir64 / $jml_dataset, 2) + (-$jml_mekongga / $jml_dataset) * log($jml_mekongga / $jml_dataset, 2) + (-$jml_situ_bagendit / $jml_dataset) * log($jml_situ_bagendit / $jml_dataset, 2));

        $entrophy_sr = entrophy($suhu_rendah, $sr_ciherang, $sr_ir64, $sr_mekongga, $sr_bagendit);

        $entrophy_ss = entrophy($suhu_sedang, $ss_ciherang, $ss_ir64, $ss_mekongga, $ss_bagendit);

        $entrophy_st = entrophy($suhu_tinggi, $st_ciherang, $st_ir64, $st_mekongga, $st_bagendit);

        $entrophy_kr = entrophy($kadar_air_rendah, $kr_ciherang, $kr_ir64, $kr_mekongga, $kr_bagendit);

        $entrophy_kt = entrophy($kadar_air_tinggi, $kt_ciherang, $kt_ir64, $kt_mekongga, $kt_bagendit);

        $entrophy_cr = entrophy($curah_hujan_rendah, $cr_ciherang, $cr_ir64, $cr_mekongga, $cr_bagendit);

        $entrophy_ct = entrophy($curah_hujan_tinggi, $ct_ciherang, $ct_ir64, $ct_mekongga, $ct_bagendit);

        $entrophy_pr = entrophy($ph_rendah, $pr_ciherang, $pr_ir64, $pr_mekongga, $pr_bagendit);

        $entrophy_ps = entrophy($ph_sedang, $ps_ciherang, $ps_ir64, $ps_mekongga, $ps_bagendit);

        $entrophy_pt = entrophy($ph_tinggi, $pt_ciherang, $pt_ir64, $pt_mekongga, $pt_bagendit);

        $entrophy_tr = entrophy($topografi_rendah, $tr_ciherang, $tr_ir64, $tr_mekongga, $tr_bagendit);

        $entrophy_ts = entrophy($topografi_sedang, $ts_ciherang, $ts_ir64, $ts_mekongga, $ts_bagendit);

        $entrophy_tt = entrophy($topografi_tinggi, $tt_ciherang, $tt_ir64, $tt_mekongga, $tt_bagendit);

        $gain_suhu = (gain1($nilai_entrophy, $jml_dataset, $suhu_rendah, $suhu_sedang, $suhu_tinggi, $entrophy_sr, $entrophy_ss, $entrophy_st));

        $gain_kadar_air = is_nan(gain2($nilai_entrophy, $jml_dataset, $kadar_air_rendah, $kadar_air_tinggi, $entrophy_kr, $entrophy_kt));
        $gain_kadar_air = toInt($gain_kadar_air);

        $gain_curah_hujan = (gain2($nilai_entrophy, $jml_dataset, $curah_hujan_rendah, $curah_hujan_tinggi, $entrophy_cr, $entrophy_ct));

        $gain_ph = is_nan(gain1($nilai_entrophy, $jml_dataset, $ph_rendah, $ph_sedang, $ph_tinggi, $entrophy_pr, $entrophy_ps, $entrophy_pt));
        $gain_ph = toInt($gain_ph);

        $gain_topografi = (gain1($nilai_entrophy, $jml_dataset, $topografi_rendah, $topografi_sedang, $topografi_tinggi, $entrophy_tr, $entrophy_ts, $entrophy_tt));

        $data = array(

            "total" => array(
                'jml_dataset' => $jml_dataset,
                'jml_ciherang' => $jml_ciherang,
                'jml_ir64' => $jml_ir64,
                'jml_mekongga' => $jml_mekongga,
                'jml_situ_bagendit' => $jml_situ_bagendit,
                'entrophy_total' => $nilai_entrophy
            ),
            "suhu" => array(
                'suhu_rendah' => $suhu_rendah,
                'suhu_sedang' => $suhu_sedang,
                'suhu_tinggi' => $suhu_tinggi,
                'sr_ciherang' => $sr_ciherang,
                'sr_ir64' => $sr_ir64,
                'sr_mekongga' => $sr_mekongga,
                'sr_bagendit' => $sr_bagendit,
                'entrophy_sr' => $entrophy_sr,
                'ss_ciherang' => $ss_ciherang,
                'ss_ir64' => $ss_ir64,
                'ss_mekongga' => $ss_mekongga,
                'entrophy_ss' => $entrophy_ss,
                'ss_bagendit' => $ss_bagendit,
                'st_ciherang' => $st_ciherang,
                'st_ir64' => $st_ir64,
                'st_mekongga' => $st_mekongga,
                'st_bagendit' => $st_bagendit,
                'entrophy_st' => $entrophy_st,

            ),
            "kadar_air" => array(
                'kadar_air_rendah' => $kadar_air_rendah,
                'kadar_air_tinggi' => $kadar_air_tinggi,
                'kr_ciherang' => $kr_ciherang,
                'kr_ir64' => $kr_ir64,
                'kr_mekongga' => $kr_mekongga,
                'kr_bagendit' => $kr_bagendit,
                'entrophy_kr' => $entrophy_kr,
                'kt_ciherang' => $kt_ciherang,
                'kt_ir64' => $kt_ir64,
                'kt_mekongga' => $kt_mekongga,
                'kt_bagendit' => $kt_bagendit,
                'entrophy_kt' => $entrophy_kt,

            ),
            "curah_hujan" => array(
                'curah_hujan_rendah' => $curah_hujan_rendah,
                'curah_hujan_tinggi' => $curah_hujan_tinggi,
                'cr_ciherang' => $cr_ciherang,
                'cr_ir64' => $cr_ir64,
                'cr_mekongga' => $cr_mekongga,
                'cr_bagendit' => $cr_bagendit,
                'entrophy_cr' => $entrophy_cr,
                'ct_ciherang' => $ct_ciherang,
                'ct_ir64' => $ct_ir64,
                'ct_mekongga' => $ct_mekongga,
                'ct_bagendit' => $ct_bagendit,
                'entrophy_ct' => $entrophy_ct,

            ),
            "ph" => array(
                'ph_rendah' => $ph_rendah,
                'ph_sedang' => $ph_sedang,
                'ph_tinggi' => $ph_tinggi,
                'pr_ciherang' => $pr_ciherang,
                'pr_ir64' => $pr_ir64,
                'pr_mekongga' => $pr_mekongga,
                'entrophy_pr' => $entrophy_pr,
                'pr_bagendit' => $pr_bagendit,
                'ps_ciherang' => $ps_ciherang,
                'ps_ir64' => $ps_ir64,
                'ps_mekongga' => $ps_mekongga,
                'ps_bagendit' => $ps_bagendit,
                'entrophy_ps' => $entrophy_ps,
                'pt_ciherang' => $pt_ciherang,
                'pt_ir64' => $pt_ir64,
                'pt_mekongga' => $pt_mekongga,
                'pt_bagendit' => $pt_bagendit,
                'entrophy_pt' => $entrophy_pt,

            ),
            "topografi" => array(
                'topografi_rendah' => $topografi_rendah,
                'topografi_sedang' => $topografi_sedang,
                'topografi_tinggi' => $topografi_tinggi,
                'tr_ciherang' => $tr_ciherang,
                'tr_ir64' => $tr_ir64,
                'tr_mekongga' => $tr_mekongga,
                'tr_bagendit,' => $tr_bagendit,
                'entrophy_tr' => $entrophy_tr,
                'ts_ciherang' => $ts_ciherang,
                'ts_ir64' => $ts_ir64,
                'ts_mekongga' => $ts_mekongga,
                'ts_bagendit' => $ts_bagendit,
                'entrophy_ts' => $entrophy_ts,
                'tt_ciherang' => $tt_ciherang,
                'tt_ir64' => $tt_ir64,
                'tt_mekongga' => $tt_mekongga,
                'tt_bagendit' => $tt_bagendit,
                'entrophy_tt' => $entrophy_tt,

            ),

            'gain' => array(
                'gain_suhu' => $gain_suhu,
                'gain_kadar_air' => $gain_kadar_air,
                'gain_curah_hujan' => $gain_curah_hujan,
                'gain_ph' => $gain_ph,
                'gain_topografi' => $gain_topografi
            )

        );


        // $data1['x'] = $data['gain']['gain_kadar_air'];
        // $data1['y'] = $data['gain']['gain_ph'];
        //$data1 = $data;
        //$data = $this->db->list_fields('tb_dataset_kategori');
        return $data;
    }

    public function Prediksi($a, $b)
    {
        $variabel = $this->db->query("SELECT NAMA,JUMLAH FROM `tb_gain` ORDER BY JUMLAH DESC LIMIT 2")->result_array();

        $x = $variabel[0]['NAMA'];
        $y = $variabel[1]['NAMA'];

        $x = $a;
        $y = $b;
        if ($x == "Tinggi") {
            $hasil = 'Ciherang';
        } elseif ($x == "Rendah" && $y == "Tinggi") {
            $hasil = 'IR64';
        } else {
            $hasil = 'Mekongga';
        }
        return $hasil;
    }
}
