<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Model_dataset extends CI_Model
{
    public function ambil_dataset()
    {
        $query = " SELECT `tb_dataset_kategori`.*, `tb_varietas`.`nm_var`
            FROM `tb_dataset_kategori` INNER JOIN `tb_varietas` ON `tb_dataset_kategori`.`id_var` = `tb_varietas`.`id_var` ORDER BY `id` DESC
        ";
        return $this->db->query($query)->result_array();
        // $this->db->select('tb_dataset');
        // $this->db->select('*');
        // $this->db->join('tb_varietas', 'tb_varietas.id_var = tb_dataset.id');
        // return $this->db->get();
    }

    public function ambil_histori()
    {
        $query = " SELECT `tb_histori`.*, `tb_varietas`.`nm_var`
            FROM `tb_histori` INNER JOIN `tb_varietas` ON `tb_histori`.`id_var` = `tb_varietas`.`id_var`
        ORDER BY `id_histori` DESC";
        return $this->db->query($query)->result_array();
    }
}
