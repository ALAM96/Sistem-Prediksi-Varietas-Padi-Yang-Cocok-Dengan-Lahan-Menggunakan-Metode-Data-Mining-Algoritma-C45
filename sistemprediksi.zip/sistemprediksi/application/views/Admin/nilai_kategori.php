<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4 mt-3">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-info">Nilai Kategorisasi</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Nilai Satu</th>
                            <th scope="col">Nilai Kedua</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($nkategori as $nk) :  ?>
                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $nk['nama_variabel']; ?></td>
                                <td><?php echo $nk['nilai1']; ?></td>
                                <td><?php echo $nk['nilai2']; ?></td>
                                <td><button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?php echo $nk['id_nkategori']; ?>">Ubah</button></td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Modal Edit -->
<?php $i = 1;
foreach ($nkategori as $nk) : $i++; ?>
    <div class="modal fade" id="edit<?php echo $nk['id_nkategori']; ?>" tabindex="-1" role="dialog" aria-labelledby="editLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editLabel">Ubah Nilai Kategori</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php echo form_open_multipart('Admin/proses_ubah_nkategori'); ?>
                <div class="modal-body">
                    <input type="hidden" name="id_nkategori" id="id_nkategori" value="<?php echo $nk['id_nkategori']; ?>">
                    <div class="row">
                        <label for="nama_variabel" class="col-sm-4 col-form-label">Nama Variabel</label>
                        <div class="form-group">
                            <input type="text" name="nama_variabel" class="form-control" id="nama_variabel" placeholder="Masukan nilai kesatu" value="<?php echo $nk['nama_variabel']; ?>">
                        </div>
                    </div>
                    <div class="row">
                        <label for="nilai1" class="col-sm-4 col-form-label">Nilai ke-1</label>
                        <div class="form-group">
                            <input type="text" name="nilai1" class="form-control" id="nilai1" placeholder="Masukan nilai kesatu" value="<?php echo $nk['nilai1']; ?>">
                        </div>
                    </div>
                    <div class="row">
                        <label for="nilai2" class="col-sm-4 col-form-label">Nilai ke-2</label>
                        <div class="form-group">
                            <input type="text" name="nilai2" class="form-control" id="nilai2" placeholder="Masukan nilai kedua" value="<?php echo $nk['nilai2']; ?>">
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-info">Simpan</button>
                </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
<?php endforeach; ?>