<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row">

        <div class="col-lg-5">
            <h1 class="h3 mb-4 text-gray-800"> Form Prediksi Varietas </h1>
            <form action="<?= base_url('Admin/proses_prediksi'); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" name="nama" class="form-control" id="nama" placeholder="Masukan Nama anda" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">

                    </div>
                    <div class="form-group">
                        <input type="text" name="suhu" class="form-control" id="suhu" placeholder="Masukan Nilai Suhu 0-100 (Celcius)" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">

                    </div>
                    <div class="form-group">
                        <input type="text" name="kadar_air" class="form-control" id="kadar_air" placeholder="Masukan Nilai Kadar Air 0-100 (%)" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">

                    </div>
                    <div class="form-group">
                        <input type="text" name="curah_hujan" class="form-control" id="curah_hujan" placeholder="Masukan Nilai Curah Hujan 0-100 (mm/hari)" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">

                    </div>
                    <div class="form-group">
                        <input type="text" name="ph" class="form-control" id="ph" placeholder="Masukan Nilai pH Tanah 0-14" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">

                    </div>
                    <div class="form-group">
                        <input type="text" name="topografi" class="form-control" id="topografi" placeholder="Masukan Nilai Topografi (mdpl)" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">

                    </div>
                    <div class="modal-footer">
                        <a href="<?= base_url('Admin'); ?>" class="btn btn-secondary">Kembali</a>
                        <button type="submit" class="btn btn-primary">Prediksi</button>
                        <a href="<?= base_url('Admin/generate'); ?>" class="btn btn-info">Generate Rule</a>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-lg-1"></div>
        <div class="col-lg-5">
            <h1 class="h3 mb-4 text-gray-800"> Hasil Prediksi Varietas </h1>
            <div class="card">
                <div class="card-body">
                    <h4>
                        Hasil Belum Ada
                    </h4>
                    <h6><b>Silahkan Isi Form dengan Benar untuk Melihat Hasil Prediksi</b></h6>
                </div>
            </div>
            <div class="mt-2 mb-2"></div>
            <b>Rule diperbaharui Tanggal <?php echo date('d-m-Y H:i:s', strtotime($waktu[0]['DATETIME'])); ?> dengan total <?= $jumlah; ?> dataset oleh <?= $user['username']; ?></b>
            <?= $this->session->flashdata('message'); ?>
        </div>

    </div>
</div>

<!-- Generate Modal-->
<div class="modal fade" id="generate" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Rule Prediksi Telah Diperbaharui</div>
            <div class="modal-footer">
                <a href="" class="btn btn-secondary" type="button" data-dismiss="modal">OK</a>
            </div>
        </div>
    </div>
</div>