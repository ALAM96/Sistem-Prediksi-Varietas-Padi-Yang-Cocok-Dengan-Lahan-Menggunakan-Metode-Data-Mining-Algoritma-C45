<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"> Form Edit Data Set </h1>
    <div class="col-lg-6">
        <form action="<?= base_url('Admin/Proses_edit_dataset'); ?>" method="post">
            <div class="modal-body">
                <input type="hidden" name="id" id="id" value="<?= $dt_angka['id_dataset']; ?>">
                <div class="form-group row">
                    <label for="suhu" class="col-sm-3 col-form-label">Suhu</label>
                    <div class="col-sm-9">
                        <input type="text" name="suhu" class="form-control" id="suhu" placeholder="Masukan Nilai Suhu 0-100" value="<?= $dt_angka['d_suhu']; ?>">
                        <?= form_error('suhu', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="kadar_air" class="col-sm-3 col-form-label">Kadar Air</label>
                    <div class="col-sm-9">
                        <input type="text" name="kadar_air" class="form-control" id="kadar_air" placeholder="Masukan Nilai Kadar Air 0-100" value="<?= $dt_angka['d_kadar_air']; ?>">
                        <?= form_error('kadar_air', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="curah_hujan" class="col-sm-3 col-form-label">Curah Hujan</label>
                    <div class="col-sm-9">
                        <input type="text" name="curah_hujan" class="form-control" id="curah_hujan" placeholder="Masukan Nilai Curah Hujan 0-100" value="<?= $dt_angka['d_curah_hujan']; ?>">
                        <?= form_error('curah_hujan', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="ph" class="col-sm-3 col-form-label">pH Tanah</label>
                    <div class="col-sm-9">
                        <input type="text" name="ph" class="form-control" id="ph" placeholder="Masukan Nilai pH Tanah 0-14" value="<?= $dt_angka['d_ph']; ?>">
                        <?= form_error('ph', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="topografi" class="col-sm-3 col-form-label">Topografi</label>
                    <div class="col-sm-9">
                        <input type="text" name="topografi" class="form-control" id="topografi" placeholder="Masukan Nilai Topografi 0-2000" value="<?= $dt_angka['d_topografi']; ?>">
                        <?= form_error('topografi', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="id_var" class="col-sm-3 col-form-label">Varietas</label>
                    <div class="col-sm-9">
                        <select class="form-control" id="id_var" name="id_var">
                            <option value="<?= $dt_angka['id_var']; ?>"><?php if ($dt_angka['id_var'] == 1) {
                                                                            echo "Ciherang";
                                                                        } elseif ($dt_angka['id_var'] == 2) {
                                                                            echo "IR64";
                                                                        } elseif ($dt_angka['id_var'] == 3) {
                                                                            echo "Mekongga";
                                                                        } else {
                                                                            echo "Situ Bagendit";
                                                                        }; ?></option>
                            <?php foreach ($varietas as $var) : ?>
                                <option value="<?php echo $var['id_var']; ?>"><?php echo $var['nm_var']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="<?= base_url('Admin/dataset'); ?>" class="btn btn-secondary">Kembali</a>
                <button type="submit" class="btn btn-info">Simpan</button>
            </div>
    </div>
    </form>
</div>