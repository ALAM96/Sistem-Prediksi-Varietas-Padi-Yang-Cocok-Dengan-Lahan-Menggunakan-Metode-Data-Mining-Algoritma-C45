<?php

$this->db->query('DELETE FROM tb_gain');
// var_dump($rule['gain'])'
$data[] = json_encode($rule);
// print_r(array_keys($rule['gain']));
$nama = array(
    'gain_suhu',
    'gain_kadar_air',
    'gain_curah_hujan',
    'gain_ph',
    'gain_topografi'
);
$i = 0;
foreach ($rule['gain'] as $key => $var) {
    $this->db->query("insert into tb_gain values('','" . $nama[$i] . "','" . $var . "','" . date('Y-m-d H:i:s') . "')");
    $i++;
}
// echo $d[2];
