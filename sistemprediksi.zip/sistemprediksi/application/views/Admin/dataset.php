<div class="container-fluid">
    <!-- <h1 class="h3 mb-4 text-gray-800">DATA USER</h1>

  <div class="row">
    <div class="col-lg-6"> -->

    <?= form_error('username', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    <?= form_error('password', '<div class="alert alert-danger" role="alert">', '</div>'); ?>



    <!-- <table class="table table-hover">
        <thead> -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-info">Data Set
                <a href="<?php echo base_url() ?>Admin/tambah_dataset" class="btn btn-info btn-sm float-right">Tambah Data Set</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Suhu</th>
                            <th scope="col">Kadar Air</th>
                            <th scope="col">Curah Hujan</th>
                            <th scope="col">pH Tanah</th>
                            <th scope="col">Topografi</th>
                            <th scope="col">Varietas</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($dataset as $data) : ?>

                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $data['k_suhu']; ?></td>
                                <td><?= $data['k_kadar_air']; ?></td>
                                <td><?= $data['k_curah_hujan']; ?></td>
                                <td><?= $data['k_ph']; ?></td>
                                <td><?= $data['k_topografi']; ?></td>
                                <td><?= $data['nm_var'];  ?></td>
                                <td>
                                    <a href="<?php echo base_url() ?>Admin/edit_dataset/<?php echo $data['id']; ?>" class="btn btn-warning btn-sm">Ubah</a>
                                    <a class="btn btn-danger btn-sm" href="" data-toggle="modal" data-target="#hapusModal<?php echo $data['id']; ?>">Hapus</a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- Hapus Modal-->
<?php $i = 0;
foreach ($dataset as $data) : $i++; ?>
<div class="modal fade" id="hapusModal<?php echo $data['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Hapus Data Ini ?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Tekan hapus jika anda ingin menghapus data ini</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                <a class="btn btn-info" href="<?php echo base_url() ?>Admin/hapus_dataset/<?php echo $data['id']; ?>">hapus</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>