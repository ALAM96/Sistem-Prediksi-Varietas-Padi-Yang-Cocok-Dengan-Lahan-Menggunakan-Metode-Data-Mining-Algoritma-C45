<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"> Form Tambah Data Set </h1>
    <div class="col-lg-6">
        <form action="<?= base_url('Admin/tambah_dataset'); ?>" method="post">
            <div class="modal-body">
                <div class="form-group">
                    <input type="text" name="suhu" class="form-control" id="suhu" placeholder="Masukan Nilai Suhu 0-100">
                    <?= form_error('suhu', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
                <div class="form-group">
                    <input type="text" name="kadar_air" class="form-control" id="kadar_air" placeholder="Masukan Nilai Kadar Air 0-100">
                    <?= form_error('kadar_air', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
                <div class="form-group">
                    <input type="text" name="curah_hujan" class="form-control" id="curah_hujan" placeholder="Masukan Nilai Curah Hujan 0-100">
                    <?= form_error('curah_hujan', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
                <div class="form-group">
                    <input type="text" name="ph" class="form-control" id="ph" placeholder="Masukan Nilai pH Tanah 0-14">
                    <?= form_error('ph', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
                <div class="form-group">
                    <input type="text" name="topografi" class="form-control" id="topografi" placeholder="Masukan Nilai Topografi 0-2000">
                    <?= form_error('topografi', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
                <div class="form-group">

                    <select class="form-control" id="id_var" name="id_var">
                        <option disabled selected> Pilih </option>
                        <?php foreach ($varietas as $var) : ?>
                            <option value="<?php echo $var['id_var']; ?>"><?php echo $var['nm_var']; ?></option>
                        <?php endforeach; ?>
                    </select>

                </div>
                <div class="modal-footer">
                    <a href="<?= base_url('Admin/dataset'); ?>" class="btn btn-secondary">Kembali</a>
                    <button type="submit" class="btn btn-info">Tambah</button>
                </div>
            </div>
        </form>
    </div>

</div>