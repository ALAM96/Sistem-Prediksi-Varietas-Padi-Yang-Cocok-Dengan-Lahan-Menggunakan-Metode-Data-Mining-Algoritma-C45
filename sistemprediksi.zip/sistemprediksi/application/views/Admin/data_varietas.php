<div class="container-fluid">

  <?= form_error('nm_var', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
  <?= form_error('keunggulan', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
  <?= form_error('kekurangan', '<div class="alert alert-danger" role="alert">', '</div>'); ?>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-info">Varietas Padi di Kabupaten Tasikmalaya
        <a href="" class="btn btn-info btn-sm float-right" data-toggle="modal" data-target="#varietas">Tambah Varietas</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th scope="col">No</th>
              <th scope="col">Nama Varietas</th>
              <th scope="col">Keunggulan</th>
              <th scope="col">Kekurangan</th>
              <th scope="col">AKSI</th>
            </tr>
          </thead>
          <tbody>
            <?php $i = 1; ?>
            <?php foreach ($varietas as $var) :  ?>
              <tr>
                <th scope="row"><?= $i; ?></th>
                <td><?= $var['nm_var']; ?></td>
                <td><?= $var['keunggulan']; ?></td>
                <td><?= $var['kekurangan']; ?></td>
                <td>
                  <button class="badge badge-warning" data-toggle="modal" data-target="#editmodal<?php echo $var['id_var']; ?>">Ubah</button>
                  <a class="badge badge-danger " href="" data-toggle="modal" data-target="#hapusModal<?php echo $var['id_var']; ?>">Hapus</a>
                </td>
              </tr>
              <?php $i++; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="varietas" tabindex="-1" role="dialog" aria-labelledby="varietasLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varietasLabel">Tambah Varietas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?= base_url('Admin/varietas'); ?>" method="post">
        <div class="modal-body">
          <input type="hidden" name="id_var" id="id_var" value="<?php echo $var['id_var']; ?>">
          <div class="form-group">
            <input type="text" name="nm_var" class="form-control" id="nm_var" placeholder="Masukan Nama Varietas">
          </div>
          <div class="form-group">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="keunggulan" placeholder="Masukan Keunggulan Varietas"></textarea>
          </div>
          <div class="form-group">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="kekurangan" placeholder="Masukan Kekurangan Varietas"></textarea>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            <button type="submit" class="btn btn-info">Tambah</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit -->
<?php $i = 0;
foreach ($varietas as $var) : $i++; ?>
  <div class="modal fade" id="editmodal<?php echo $var['id_var']; ?>" tabindex="-1" role="dialog" aria-labelledby="editLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editLabel">Ubah Data Varietas</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php echo form_open_multipart('Admin/Proses_edit_varietas'); ?>
        <div class="modal-body">
          <input type="hidden" name="id_var" id="id_var" value="<?php echo $var['id_var']; ?>">
          <div class="form-group">
            <input type="text" name="nm_var" class="form-control" id="nm_var" placeholder="Masukan Nama Varietas" value="<?php echo $var['nm_var']; ?>">
          </div>
          <div class="form-group">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="keunggulan"><?php echo $var['keunggulan']; ?></textarea>
          </div>
          <div class="form-group">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="kekurangan" placeholder="Masukan Kekurangan Varietas"><?php echo $var['kekurangan']; ?></textarea>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-info">Simpan</button>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
<?php endforeach; ?>

<!-- Hapus Modal-->
<?php $i = 0;
foreach ($varietas as $var) : $i++; ?>
<div class="modal fade" id="hapusModal<?php echo $var['id_var']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hapus Data Ini ?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Tekan hapus jika anda ingin menghapus data ini</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
        <a class="btn btn-info" href="<?php echo base_url() ?>Admin/hapus_varietas/<?php echo $var['id_var']; ?>">hapus</a>
      </div>
    </div>
  </div>
</div>
<?php endforeach; ?>