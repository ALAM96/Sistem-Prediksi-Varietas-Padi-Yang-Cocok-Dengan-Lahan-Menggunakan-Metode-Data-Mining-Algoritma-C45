<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">VARIETAS PADI DI KABUPATEN TASIKMALAYA</h1>

  <div class="row">
    <?php foreach ($varietas as $var) :  ?>
      <div class="col-6 mt-2">
        <div class="card">
          <div class="card-body">
            <h4><?= $var['nm_var']; ?></h4>
            <h6><b>Keunggulan</b></h6>
            <p class="card-text"><?= $var['keunggulan']; ?></p>
            <h6><b>Kekurangan</b></h6>
            <p class="card-text"><?= $var['kekurangan']; ?></p>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

</div>