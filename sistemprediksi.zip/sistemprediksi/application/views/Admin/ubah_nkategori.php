<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"> Form Ubah Nilai Kategori </h1>
    <div class="col-lg-6">
        <form action="<?= base_url('Admin/proses_ubah_nkategori'); ?>" method="post">
            <div class="modal-body">
                <input type="hidden" name="id" id="id" value="<?= $nkategori['id_nkategori']; ?>">
                <div class="form-group row">
                    <label for="suhu" class="col-sm-3 col-form-label">Suhu</label>
                    <div class="col-sm-9">
                        <input type="text" name="suhu" class="form-control" id="suhu" placeholder="Masukan Nilai Suhu 0-100" value="<?= $nkategori['d_suhu']; ?>">
                        <?= form_error('suhu', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="kadar_air" class="col-sm-3 col-form-label">Kadar Air</label>
                    <div class="col-sm-9">
                        <input type="text" name="kadar_air" class="form-control" id="kadar_air" placeholder="Masukan Nilai Kadar Air 0-100" value="<?= $nkategori['d_kadar_air']; ?>">
                        <?= form_error('kadar_air', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="curah_hujan" class="col-sm-3 col-form-label">Curah Hujan</label>
                    <div class="col-sm-9">
                        <input type="text" name="curah_hujan" class="form-control" id="curah_hujan" placeholder="Masukan Nilai Curah Hujan 0-100" value="<?= $nkategori['d_curah_hujan']; ?>">
                        <?= form_error('curah_hujan', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="ph" class="col-sm-3 col-form-label">pH Tanah</label>
                    <div class="col-sm-9">
                        <input type="text" name="ph" class="form-control" id="ph" placeholder="Masukan Nilai pH Tanah 0-14" value="<?= $nkategori['d_ph']; ?>">
                        <?= form_error('ph', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="<?= base_url('Admin/dataset'); ?>" class="btn btn-secondary">Kembali</a>
                <button type="submit" class="btn btn-info">Simpan</button>
            </div>
    </div>
    </form>
</div>