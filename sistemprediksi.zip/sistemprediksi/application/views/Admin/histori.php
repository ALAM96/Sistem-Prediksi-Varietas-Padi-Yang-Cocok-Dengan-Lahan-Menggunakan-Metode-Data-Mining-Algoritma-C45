<div class="container-fluid">


    <!-- DataTales Example -->
    <div class="card shadow mb-4 mt-3">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-info">Histori Prediksi Varietas</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Suhu</th>
                            <th scope="col">Kadar Air</th>
                            <th scope="col">Curah Hujan</th>
                            <th scope="col">pH</th>
                            <th scope="col">Topografi</th>
                            <th scope="col">Hasil</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($histori as $h) :  ?>
                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $h['nama']; ?></td>
                                <td><?php if ($h['h_suhu'] < $nkategori[0]['nilai1']) {
                                        echo "Rendah";
                                    } elseif ($h['h_suhu'] < $nkategori[0]['nilai2']) {
                                        echo "Sedang";
                                    } else {
                                        echo "Tinggi";
                                    }; ?></td>
                                <td><?php if ($h['h_kadar_air'] < $nkategori[1]['nilai1']) {
                                        echo "Rendah";
                                    } elseif ($h['h_kadar_air'] < $nkategori[1]['nilai2']) {
                                        echo 'Sedang';
                                    } else {
                                        echo "Tinggi";
                                    };  ?></td>
                                <td><?php if ($h['h_curah_hujan'] <= $nkategori[2]['nilai1']) {
                                        echo "Rendah";
                                    } elseif ($h['h_curah_hujan'] < $nkategori[2]['nilai2']) {
                                        echo 'Sedang';
                                    } else {
                                        echo "Tinggi";
                                    };  ?></td>
                                <td><?php if ($h['h_pH'] <= $nkategori[3]['nilai1']) {
                                        echo "Rendah";
                                    } elseif ($h['h_pH'] < $nkategori[3]['nilai2']) {
                                        echo "Sedang";
                                    } else {
                                        echo "Tinggi";
                                    }; ?></td>
                                <td><?php if ($h['h_topografi'] <= 500) {
                                        echo "Rendah";
                                    } elseif ($h['h_topografi'] <= 1000) {
                                        echo "Sedang";
                                    } else {
                                        echo "Tinggi";
                                    }; ?></td>
                                <td><?= $h['nm_var']; ?></td>
                                <td><a class="btn btn-danger btn-sm" href="" data-toggle="modal" data-target="#hapusModal<?php echo $h['id_histori']; ?>">Hapus</a></td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Hapus Modal-->
<?php $i = 0;
foreach ($histori as $h) : $i++; ?>
    <div class="modal fade" id="hapusModal<?php echo $h['id_histori']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Data Ini ?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Tekan hapus jika anda ingin menghapus data ini</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    <a class="btn btn-info" href="<?php echo base_url() ?>Admin/hapus_histori/<?php echo $h['id_histori']; ?>">hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>