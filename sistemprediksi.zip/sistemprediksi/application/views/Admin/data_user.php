<div class="container-fluid">
  <!-- <h1 class="h3 mb-4 text-gray-800">DATA USER</h1>

  <div class="row">
    <div class="col-lg-6"> -->

  <?= form_error('username', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
  <?= form_error('password', '<div class="alert alert-danger" role="alert">', '</div>'); ?>



  <!-- <table class="table table-hover">
        <thead> -->
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-info">Data Admin
        <!-- <a href="" class="btn btn-info btn-sm float-right" data-toggle="modal" data-target="#exampleModal">Tambah User</a> -->
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th scope="col">No</th>
              <th scope="col">Username</th>
              <th scope="col">Password</th>
              <th scope="col">AKSI</th>
            </tr>
          </thead>
          <tbody>
            <?php $i = 1; ?>
            <?php foreach ($datauser as $us) :  ?>
              <tr>
                <th scope="row"><?= $i; ?></th>
                <td><?= $us['username']; ?></td>
                <td><?= $us['password']; ?></td>
                <td>

                  <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?php echo $us['id_user']; ?>">Ubah</button>
                  <!-- <a class="btn btn-danger btn-sm" href="" data-toggle="modal" data-target="#hapusModal">Hapus</a> -->
                </td>
              </tr>
              <?php $i++; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>

<!-- Modal Tambah -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?= base_url('Admin/user'); ?>" method="post">
        <div class="modal-body">
          <div class="form-group">
            <input type="text" name="username" class="form-control" id="username" placeholder="Masukan Username" autocomplete="off">
          </div>
          <div class="form-group">
            <input type="text" name="password" class="form-control" id="password" placeholder="Masukan Password" autocomplete="off">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-info">Tambah</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit -->
<?php $i = 1;
foreach ($datauser as $us) : $i++; ?>
  <div class="modal fade" id="edit<?php echo $us['id_user']; ?>" tabindex="-1" role="dialog" aria-labelledby="editLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editLabel">Ubah Data Admin</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php echo form_open_multipart('Admin/Proses_edit_user'); ?>
        <div class="modal-body">
          <input type="hidden" name="id_user" id="id_user" value="<?php echo $us['id_user']; ?>">
          <div class="form-group">
            <input type="text" name="username" class="form-control" id="username" placeholder="Masukan Username" value="<?php echo $us['username']; ?>">
          </div>
          <div class="form-group">
            <input type="text" name="password" class="form-control" id="password" placeholder="Masukan Password" value="<?php echo $us['password']; ?>">
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-info">Simpan</button>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
<?php endforeach; ?>

<!-- Hapus Modal-->
<div class="modal fade" id="hapusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hapus Data Ini ?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Tekan hapus jika anda ingin menghapus data ini</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
        <a class="btn btn-info" href="<?php echo base_url() ?>Admin/hapus_user/<?php echo $us['id_user']; ?>">hapus</a>
      </div>
    </div>
  </div>
</div>