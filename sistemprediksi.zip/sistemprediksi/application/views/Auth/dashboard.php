<div class="container shadow">
  <div class="row"></div>
  <div id="carouselExampleIndicators" class="carousel slide mb-3 mt-3" data-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="<?= base_url('assets/img/padi.jpg'); ?>" class="d-block w-100" alt="...">
      </div>
    </div>
  </div>
  <!-- <div class="jumbotron mt-3">
    <center>
      <h1 class="display-4">SELAMAT DATANG</h1>
      <p class="lead">sistem prediksi varietas padi sesuai dengan kondisi lahan dan cuaca</p>
    </center>
    <hr class="my-2">
  </div> -->

  <center>
    <a href="<?= base_url('Auth/histori'); ?>" class="btn btn-info" type="submit">Histori Prediksi</a>
    <a href="<?= base_url('Auth/prediksi_user'); ?>" class="btn btn-info" type="submit">Prediksi Varietas</a>
    <a href="<?= base_url('Auth/login'); ?>" class="btn btn-info" type="submit">Login</a>
    <h1 class="h3 mb-4 text-gray-800 mt-5">VARIETAS PADI DI KABUPATEN TASIKMALAYA</h1>
  </center>
  <div class="row">
    <?php foreach ($varietas as $var) :  ?>
      <div class="col-6 mb-3">
        <div class="card">
          <div class="card-body shadow">
            <h4><?= $var['nm_var']; ?></h4>
            <h6><b>Keunggulan</b></h6>
            <p class="card-text"><?= $var['keunggulan']; ?></p>
            <h6><b>Kekurangan</b></h6>
            <p class="card-text"><?= $var['kekurangan']; ?></p>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
