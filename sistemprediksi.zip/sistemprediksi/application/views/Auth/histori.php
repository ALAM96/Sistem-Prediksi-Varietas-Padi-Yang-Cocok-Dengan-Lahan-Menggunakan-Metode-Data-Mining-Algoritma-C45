<div class="container-fluid">

    <?= form_error('nm_var', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    <?= form_error('keunggulan', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    <?= form_error('kekurangan', '<div class="alert alert-danger" role="alert">', '</div>'); ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4 mt-3">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-info">Histori Prediksi Varietas</h6>
            <a href="<?= base_url('Auth'); ?>" class="badge badge-info">Kembali</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Suhu</th>
                            <th scope="col">Kadar Air</th>
                            <th scope="col">Curah Hujan</th>
                            <th scope="col">pH</th>
                            <th scope="col">Topografi</th>
                            <th scope="col">Hasil</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($histori as $h) :  ?>
                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $h['nama']; ?></td>
                                <td><?php if ($h['h_suhu'] < $nkategori[0]['nilai1']) {
                                        echo "Rendah";
                                    } elseif ($h['h_suhu'] < $nkategori[0]['nilai2']) {
                                        echo "Sedang";
                                    } else {
                                        echo "Tinggi";
                                    }; ?></td>
                                <td><?php if ($h['h_kadar_air'] < $nkategori[1]['nilai1']) {
                                        echo "Rendah";
                                    } elseif ($h['h_kadar_air'] < $nkategori[1]['nilai2']) {
                                        echo 'Sedang';
                                    } else {
                                        echo "Tinggi";
                                    };  ?></td>
                                <td><?php if ($h['h_curah_hujan'] <= $nkategori[2]['nilai1']) {
                                        echo "Rendah";
                                    } elseif ($h['h_curah_hujan'] < $nkategori[2]['nilai2']) {
                                        echo 'Sedang';
                                    } else {
                                        echo "Tinggi";
                                    };  ?></td>
                                <td><?php if ($h['h_pH'] <= $nkategori[3]['nilai1']) {
                                        echo "Rendah";
                                    } elseif ($h['h_pH'] < $nkategori[3]['nilai2']) {
                                        echo "Sedang";
                                    } else {
                                        echo "Tinggi";
                                    }; ?></td>
                                <td><?php if ($h['h_topografi'] <= 500) {
                                        echo "Rendah";
                                    } elseif ($h['h_topografi'] <= 1000) {
                                        echo "Sedang";
                                    } else {
                                        echo "Tinggi";
                                    }; ?></td>
                                <td><?= $h['nm_var']; ?></td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>