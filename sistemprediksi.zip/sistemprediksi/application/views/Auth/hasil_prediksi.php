<div class="container">
    <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
    <script type="text/javascript">
        function eraseText() {
            document.getElementById("nama").value = "";
            document.getElementById("suhu").value = "";
            document.getElementById("kadar_air").value = "";
            document.getElementById("curah_hujan").value = "";
            document.getElementById("ph").value = "";
            document.getElementById("topografi").value = "";
        }
    </script>


    <!-- Outer Row -->
    <div class="row">

        <div class="col-lg-6">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg col-6">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">FORM PREDIKSI VARIETAS</h1>
                                </div>
                                <?= $this->session->flashdata('message'); ?>
                                <form class="user" method="post" action="<?= base_url('Auth/proses_prediksi'); ?>">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id="nama" name="nama" aria-describedby="emailHelp" placeholder="Masukan nama..." autocomplete="off" value="<?= set_value('nama'); ?>" maxlength="25" required>
                                        <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id="suhu" name="suhu" aria-describedby="emailHelp" placeholder="Masukan nilai Suhu...(Celcius)" autocomplete="off" value="<?= set_value('suhu'); ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57" required>
                                        <?= form_error('suhu', '<small class="text-danger pl-3">', '</small>'); ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id="kadar_air" name="kadar_air" aria-describedby="emailHelp" placeholder="Masukan nilai Kadar Air...(%)" autocomplete="off" value="<?= set_value('kadar_air'); ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57" required>
                                        <?= form_error('kadar_air', '<small class="text-danger pl-3">', '</small>'); ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id="curah_hujan" name="curah_hujan" aria-describedby="emailHelp" placeholder="Masukan nilai Curah Hujan...(mm/hari)" autocomplete="off" value="<?= set_value('curah_hujan'); ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57" required>
                                        <?= form_error('curah_hujan', '<small class="text-danger pl-3">', '</small>'); ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id="ph" name="ph" aria-describedby="emailHelp" placeholder="Masukan nilai pH..." autocomplete="off" value="<?= set_value('ph'); ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57" required>
                                        <?= form_error('ph', '<small class="text-danger pl-3">', '</small>'); ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id="topografi" name="topografi" aria-describedby="emailHelp" placeholder="Masukan nilai Topografi...(mdpl)" autocomplete="off" value="<?= set_value('topografi'); ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57" required>
                                        <?= form_error('topografi', '<small class="text-danger pl-3">', '</small>'); ?>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg col-3">
                                            <input type="button" class="btn btn-info btn-user btn-block" value="Bersihkan" onclick="javascript:eraseText();">
                                            </input>
                                        </div>
                                        <div class="col-lg col-3">
                                            <button type="submit" class="btn btn-info btn-user btn-block" id="tekan">
                                                Prediksi
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <div class="text-center">
                                    <a class="small" href="<?= base_url('Auth'); ?>">Kembali</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="col-lg-6" id="hasil">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg col-6">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">HASIL PREDIKSI VARIETAS</h1>
                                </div>
                                <div class="card">
                                    <div class="card-body">
                                        <h4>
                                            <?php echo $varietas['nm_var']; ?>
                                        </h4>
                                        <h6><b>Keunggulan</b></h6>
                                        <p class="card-text">
                                            <?php echo $varietas['keunggulan']; ?>
                                        </p>
                                        <h6><b>Kekurangan</b></h6>
                                        <p class="card-text">
                                            <?php echo $varietas['kekurangan']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>