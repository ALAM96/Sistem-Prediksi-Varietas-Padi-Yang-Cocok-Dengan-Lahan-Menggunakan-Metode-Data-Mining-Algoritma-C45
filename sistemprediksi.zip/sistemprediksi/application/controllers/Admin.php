<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		if (!$this->session->userdata('username')) {
			redirect('Auth/login');
		}
	}

	public function index()
	{

		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$data['varietas'] = $this->db->get('tb_varietas')->result_array();

		$data['title'] = 'Dashboard Admin';
		$this->load->view('Templates/header_admin', $data);
		$this->load->view('Templates/sidebar', $data);
		$this->load->view('Templates/topbar', $data);
		$this->load->view('Admin/dashboard_admin');
		$this->load->view('Templates/footer_admin');
	}

	public function user()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

		$data['datauser'] = $this->db->get('tb_user')->result_array();

		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');

		if ($this->form_validation->run() == false) {
			$data['title'] = 'Halaman Data Admin';
			$this->load->view('Templates/header_admin', $data);
			$this->load->view('Templates/sidebar', $data);
			$this->load->view('Templates/topbar', $data);
			$this->load->view('Admin/data_user', $data);
			$this->load->view('Templates/footer_admin');
		} else {
			$data = array(
				'username' => $this->input->post('username'),
				'password' => $this->input->post('password')
			);
			$this->db->insert('tb_user', $data);
			redirect('Admin/user');
		}
	}

	public function varietas()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

		$data['varietas'] = $this->db->get('tb_varietas')->result_array();

		$this->form_validation->set_rules('nm_var', 'Nama Varietas', 'required', ['required' => 'Nama Varietas tidak boleh kosong !']);
		$this->form_validation->set_rules('keunggulan', 'Keunggulan', 'required', ['required' => 'Keunggulan Varietas tidak boleh kosong !']);
		$this->form_validation->set_rules('kekurangan', 'Kekurangan', 'required', ['required' => 'Kekurangan Varietas tidak boleh kosong !']);

		if ($this->form_validation->run() == false) {
			$data['title'] = 'Halaman Data User';
			$this->load->view('Templates/header_admin', $data);
			$this->load->view('Templates/sidebar', $data);
			$this->load->view('Templates/topbar', $data);
			$this->load->view('Admin/data_varietas');
			$this->load->view('Templates/footer_admin');
		} else {
			$data = array(
				'nm_var' => $this->input->post('nm_var'),
				'keunggulan' => $this->input->post('keunggulan'),
				'kekurangan' => $this->input->post('kekurangan')
			);
			$this->db->insert('tb_varietas', $data);
			redirect('Admin/varietas');
		}
	}

	public function dataset()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

		$data['dataset'] = $this->Model_dataset->ambil_dataset();
		//db->get('tb_dataset')->result_array();
		//$this->M_varietas->Getdataset();
		$data['title'] = 'Halaman Data Set';
		$this->load->view('Templates/header_admin', $data);
		$this->load->view('Templates/sidebar', $data);
		$this->load->view('Templates/topbar', $data);
		$this->load->view('Admin/dataset', $data);
		$this->load->view('Templates/footer_admin');
	}

	public function hapus_user($id_user)
	{
		$this->db->where('id_user', $id_user);
		$this->db->delete('tb_user');
		redirect('Admin/user');
	}

	public function Proses_edit_user()
	{
		$data = [
			'username' => $this->input->post('username'),
			'password' => $this->input->post('password')
		];
		$this->db->where('id_user', $this->input->post('id_user'));
		$this->db->update('tb_user', $data);
		redirect('Admin/user');
	}

	public function hapus_varietas($id_var)
	{
		$this->db->where('id_var', $id_var);
		$this->db->delete('tb_varietas');
		redirect('Admin/varietas');
	}

	public function Proses_edit_varietas()
	{
		$data = [
			'nm_var' => $this->input->post('nm_var'),
			'keunggulan' => $this->input->post('keunggulan'),
			'kekurangan' => $this->input->post('kekurangan')
		];
		$this->db->where('id_var', $this->input->post('id_var'));
		$this->db->update('tb_varietas', $data);
		redirect('Admin/varietas');
	}

	public function tambah_dataset()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

		//$data['dataset'] = $this->M_varietas->getdataset();
		$data['varietas'] = $this->db->get('tb_varietas')->result_array();

		$this->form_validation->set_rules('suhu', 'Suhu', 'required', ['required' => 'nilai Suhu tidak boleh kosong !']);
		$this->form_validation->set_rules('kadar_air', 'Kadar Air', 'required', ['required' => 'nilai Kadar Air tidak boleh kosong !']);
		$this->form_validation->set_rules('curah_hujan', 'Curah Hujan', 'required', ['required' => 'nilai Curah Hujan tidak boleh kosong !']);
		$this->form_validation->set_rules('ph', 'pH Tanah', 'required', ['required' => 'nilai pH Tanah tidak boleh kosong !']);
		$this->form_validation->set_rules('topografi', 'Topografi', 'required', ['required' => 'nilai Topografi tidak boleh kosong !']);

		if ($this->form_validation->run() == false) {

			$data['title'] = 'Halaman Tambah Data Set';
			$this->load->view('Templates/header_admin', $data);
			$this->load->view('Templates/sidebar', $data);
			$this->load->view('Templates/topbar', $data);
			$this->load->view('Admin/tambah_dataset', $data);
			$this->load->view('Templates/footer_admin');
		} else {

			$nkategori = $this->db->get('tb_nilai_kategori')->result_array();

			if ($this->input->post('suhu') < $nkategori[0]['nilai1']) {
				$k_suhu = 'Rendah';
			} elseif ($this->input->post('suhu') < $nkategori[0]['nilai2']) {
				$k_suhu = 'Sedang';
			} else {
				$k_suhu = 'Tinggi';
			}

			if ($this->input->post('kadar_air') < $nkategori[1]['nilai1']) {
				$k_kadar_air = 'Rendah';
			} elseif ($this->input->post('kadar_air') < $nkategori[1]['nilai2']) {
				$k_kadar_air = 'Sedang';
			} else {
				$k_kadar_air = 'Tinggi';
			}

			if ($this->input->post('curah_hujan') <= $nkategori[2]['nilai1']) {
				$k_curah_hujan = 'Rendah';
			} elseif ($this->input->post('curah_hujan') < $nkategori[2]['nilai2']) {
				$k_curah_hujan = 'Sedang';
			} else {
				$k_curah_hujan = 'Tinggi';
			}

			if ($this->input->post('ph') <= $nkategori[3]['nilai1']) {
				$k_ph = 'Rendah';
			} elseif ($this->input->post('ph') < $nkategori[3]['nilai2']) {
				$k_ph = 'Sedang';
			} else {
				$k_ph = 'Tinggi';
			}

			if ($this->input->post('topografi') <= 500) {
				$k_topografi = 'Rendah';
			} elseif ($this->input->post('topografi') <= 1000) {
				$k_topografi = 'Sedang';
			} else {
				$k_topografi = 'Tinggi';
			}

			$id_var = $this->input->post('id_var');

			$data1 = array(
				'k_suhu' => $k_suhu,
				'k_kadar_air' => $k_kadar_air,
				'k_curah_hujan' => $k_curah_hujan,
				'k_ph' => $k_ph,
				'k_topografi' => $k_topografi,
				'id_var' => $id_var
			);

			$data = array(
				'd_suhu' => $this->input->post('suhu'),
				'd_kadar_air' => $this->input->post('kadar_air'),
				'd_curah_hujan' => $this->input->post('curah_hujan'),
				'd_ph' => $this->input->post('ph'),
				'd_topografi' => $this->input->post('topografi'),
				'id_var' => $id_var
			);

			$this->db->insert('tb_dataset_kategori', $data1);
			$this->db->insert('tb_dataset_angka', $data);
			redirect('Admin/dataset');
		}
	}

	public function hapus_dataset($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('tb_dataset_kategori');
		$this->db->where('id_dataset', $id);
		$this->db->delete('tb_dataset_angka');
		redirect('Admin/dataset');
	}

	public function edit_dataset($id)
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

		// $data1['dataset'] = $this->M_varietas->getdataset();
		$data['varietas'] = $this->db->get('tb_varietas')->result_array();
		$data['dt_angka'] = $this->db->get_where('tb_dataset_angka', ['id_dataset' => $id])->row_array();


		$this->form_validation->set_rules('suhu', 'Suhu', 'required');
		$this->form_validation->set_rules('kadar_air', 'Kadar Air', 'required');
		$this->form_validation->set_rules('curah_hujan', 'Curah Hujan', 'required');
		$this->form_validation->set_rules('ph', 'pH Tanah', 'required');
		$this->form_validation->set_rules('topografi', 'Topografi', 'required');

		if ($this->form_validation->run() == false) {

			$data['title'] = 'Halaman Edit Data Set';
			$this->load->view('Templates/header_admin', $data);
			$this->load->view('Templates/sidebar', $data);
			$this->load->view('Templates/topbar', $data);
			$this->load->view('Admin/edit_dataset', $data);
			$this->load->view('Templates/footer_admin');
		}
	}

	public function Proses_edit_dataset()
	{
		$nkategori = $this->db->get('tb_nilai_kategori')->result_array();
		if ($this->input->post('suhu') < $nkategori[0]['nilai1']) {
			$k_suhu = 'Rendah';
		} elseif ($this->input->post('suhu') < $nkategori[0]['nilai2']) {
			$k_suhu = 'Sedang';
		} else {
			$k_suhu = 'Tinggi';
		}

		if ($this->input->post('kadar_air') < $nkategori[1]['nilai1']) {
			$k_kadar_air = 'Rendah';
		} elseif ($this->input->post('kadar_air') < $nkategori[1]['nilai2']) {
			$k_kadar_air = 'Sedang';
		} else {
			$k_kadar_air = 'Tinggi';
		}

		if ($this->input->post('curah_hujan') <= $nkategori[2]['nilai1']) {
			$k_curah_hujan = 'Rendah';
		} elseif ($this->input->post('curah_hujan') < $nkategori[2]['nilai2']) {
			$k_curah_hujan = 'Sedang';
		} else {
			$k_curah_hujan = 'Tinggi';
		}

		if ($this->input->post('ph') <= $nkategori[3]['nilai1']) {
			$k_ph = 'Rendah';
		} elseif ($this->input->post('ph') < $nkategori[3]['nilai2']) {
			$k_ph = 'Sedang';
		} else {
			$k_ph = 'Tinggi';
		}

		if ($this->input->post('topografi') <= 500) {
			$k_topografi = 'Rendah';
		} elseif ($this->input->post('topografi') <= 1000) {
			$k_topografi = 'Sedang';
		} else {
			$k_topografi = 'Tinggi';
		}

		$id_var = $this->input->post('id_var');

		$data1 = array(
			'k_suhu' => $k_suhu,
			'k_kadar_air' => $k_kadar_air,
			'k_curah_hujan' => $k_curah_hujan,
			'k_ph' => $k_ph,
			'k_topografi' => $k_topografi,
			'id_var' => $id_var
		);

		$data = array(
			'd_suhu' => $this->input->post('suhu'),
			'd_kadar_air' => $this->input->post('kadar_air'),
			'd_curah_hujan' => $this->input->post('curah_hujan'),
			'd_ph' => $this->input->post('ph'),
			'd_topografi' => $this->input->post('topografi'),
			'id_var' => $id_var
		);
		$this->db->where('id_dataset', $this->input->post('id'));
		$this->db->update('tb_dataset_angka', $data);
		$this->db->where('id', $this->input->post('id'));
		$this->db->update('tb_dataset_kategori', $data1);
		redirect('Admin/dataset');
	}

	public function prediksi()
	{
		$dataset = $this->db->get('tb_dataset_kategori')->result_array();
		$data['jumlah'] = count($dataset);
		$data['waktu'] = $this->db->get('tb_gain')->result_array();
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

		$data['title'] = 'Halaman Prediksi';
		$this->load->view('Templates/header_admin', $data);
		$this->load->view('Templates/sidebar', $data);
		$this->load->view('Templates/topbar', $data);
		$this->load->view('Admin/prediksi', $data);
		$this->load->view('Templates/footer_admin');
	}

	public function generate()
	{
		$data['rule'] = $this->M_prediksi->creatRule();

		$this->db->query('DELETE FROM tb_gain');
		// var_dump($data['rule']);
		// die;
		$data[] = json_encode($data['rule']);
		// print_r(array_keys($rule['gain']));
		$nama = array(
			'suhu',
			'kadar_air',
			'curah_hujan',
			'ph',
			'topografi'
		);
		$i = 0;
		foreach ($data['rule']['gain'] as $key => $var) {
			$this->db->query("insert into tb_gain values('','" . $nama[$i] . "','" . $var . "','" . date('Y-m-d H:i:s') . "')");
			$i++;
		}
		$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Rule Berhasil Diperbaharui !</div>');
		redirect('Admin/prediksi');
	}

	public function logout()
	{
		$this->session->unset_userdata('username');
		$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Anda Telah Logout !</div>');
		redirect('Auth/login');
	}

	public function histori()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$data['histori'] = $this->Model_dataset->ambil_histori();
		$data['nkategori'] = $this->db->get('tb_nilai_kategori')->result_array();
		$data['title'] = 'Halaman Histori';
		$this->load->view('Templates/header_admin', $data);
		$this->load->view('Templates/sidebar', $data);
		$this->load->view('Templates/topbar', $data);
		$this->load->view('Admin/histori', $data);
		$this->load->view('Templates/footer_admin');
	}

	public function hapus_histori($id)
	{
		$this->db->where('id_histori', $id);
		$this->db->delete('tb_histori');
		redirect('Admin/histori');
	}

	public function proses_prediksi()
	{
		$nama = $this->input->post('nama');
		$nkategori = $this->db->get('tb_nilai_kategori')->result_array();

		if ($this->input->post('suhu') < $nkategori[0]['nilai1']) {
			$k_suhu = 'Rendah';
		} elseif ($this->input->post('suhu') < $nkategori[0]['nilai2']) {
			$k_suhu = 'Sedang';
		} else {
			$k_suhu = 'Tinggi';
		}

		if ($this->input->post('kadar_air') < $nkategori[1]['nilai1']) {
			$k_kadar_air = 'Rendah';
		} elseif ($this->input->post('kadar_air') < $nkategori[1]['nilai2']) {
			$k_kadar_air = 'Sedang';
		} else {
			$k_kadar_air = 'Tinggi';
		}

		if ($this->input->post('curah_hujan') <= $nkategori[2]['nilai1']) {
			$k_curah_hujan = 'Rendah';
		} elseif ($this->input->post('curah_hujan') < $nkategori[2]['nilai2']) {
			$k_curah_hujan = 'Sedang';
		} else {
			$k_curah_hujan = 'Tinggi';
		}

		if ($this->input->post('ph') <= $nkategori[3]['nilai1']) {
			$k_ph = 'Rendah';
		} elseif ($this->input->post('ph') < $nkategori[3]['nilai2']) {
			$k_ph = 'Sedang';
		} else {
			$k_ph = 'Tinggi';
		}

		if ($this->input->post('topografi') <= 500) {
			$k_topografi = 'Rendah';
		} elseif ($this->input->post('topografi') <= 1000) {
			$k_topografi = 'Sedang';
		} else {
			$k_topografi = 'Tinggi';
		}


		$hasil = $this->M_prediksi->Prediksi($k_kadar_air, $k_ph);
		if ($hasil == "Ciherang") {
			$hasil = 1;
		} elseif ($hasil == "IR64") {
			$hasil = 2;
		} elseif ($hasil == "Mekongga") {
			$hasil = 3;
		} else {
			$hasil = 4;
		}
		$dataset = $this->db->get('tb_dataset_kategori')->result_array();
		$data['jumlah'] = count($dataset);
		$data['waktu'] = $this->db->get('tb_gain')->result_array();

		$data['varietas'] = $this->db->get_where('tb_varietas', ['id_var' => $hasil])->row_array();
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();

		$data['title'] = 'Halaman Prediksi';
		$this->load->view('Templates/header_admin', $data);
		$this->load->view('Templates/sidebar', $data);
		$this->load->view('Templates/topbar', $data);
		$this->load->view('Admin/hasil_prediksi', $data);
		$this->load->view('Templates/footer_admin');

		$data = array(
			'nama' => $this->input->post('nama'),
			'h_suhu' => $this->input->post('suhu'),
			'h_kadar_air' => $this->input->post('kadar_air'),
			'h_curah_hujan' => $this->input->post('curah_hujan'),
			'h_ph' => $this->input->post('ph'),
			'h_topografi' => $this->input->post('topografi'),
			'id_var' => $hasil
		);

		$this->db->insert('tb_histori', $data);
	}

	public function nkategori()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$data['nkategori'] = $this->db->get('tb_nilai_kategori')->result_array();
		$data['title'] = 'Halaman Histori';
		$this->load->view('Templates/header_admin', $data);
		$this->load->view('Templates/sidebar', $data);
		$this->load->view('Templates/topbar', $data);
		$this->load->view('Admin/nilai_kategori', $data);
		$this->load->view('Templates/footer_admin');
	}

	public function ubah_nkategori()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$data['nkategori'] = $this->db->get('tb_nilai_kategori')->result_array();
		$data['title'] = 'Halaman Histori';
		$this->load->view('Templates/header_admin', $data);
		$this->load->view('Templates/sidebar', $data);
		$this->load->view('Templates/topbar', $data);
		$this->load->view('Admin/ubah_nkategori', $data);
		$this->load->view('Templates/footer_admin');
	}

	public function proses_ubah_nkategori()
	{
		$data = [
			'nama_variabel' => $this->input->post('nama_variabel'),
			'nilai1' => $this->input->post('nilai1'),
			'nilai2' => $this->input->post('nilai2')
		];
		$this->db->where('id_nkategori', $this->input->post('id_nkategori'));
		$this->db->update('tb_nilai_kategori', $data);
		redirect('Admin/nkategori');
	}
}
