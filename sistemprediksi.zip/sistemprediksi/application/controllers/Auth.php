<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('username')) {
			redirect('admin');
		}
	}

	public function index()
	{
		$data['varietas'] = $this->db->get('tb_varietas')->result_array();

		$data['title'] = 'Sistem Prediksi';
		$this->load->view('Templates/header', $data);
		$this->load->view('Auth/dashboard');
		$this->load->view('Templates/footer');
	}

	public function Login()
	{
		$this->form_validation->set_rules('username', 'Username', 'trim|required', ['required' => 'Username tidak boleng kosong !']);
		$this->form_validation->set_rules('password', 'Password', 'trim|required', ['required' => 'Password tidak boleng kosong !']);
		if ($this->form_validation->run() == false) {
			$data['title'] = 'Login Page';
			$this->load->view('Templates/header', $data);
			$this->load->view('Auth/login');
			$this->load->view('Templates/footer');
		} else {
			//validasi berhasil
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			$user = $this->db->get_where('tb_user', ['username' => $username])->row_array();

			if ($user) {
				if ($password == $user['password']) {
					$data = [
						'username' => $user['username']
					];
					$this->session->set_userdata($data);
					redirect('Admin');
				} else {
					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Salah !</div>');
					redirect('Auth/Login');
				}
			} else {
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Username Salah !</div>');
				redirect('Auth/Login');
			}
		}
	}

	public function Prediksi_user()
	{
		$data['title'] = 'Halaman Prediksi';
		$this->load->view('Templates/header', $data);
		$this->load->view('Auth/prediksi_user');
		$this->load->view('Templates/footer');
	}

	public function proses_prediksi()
	{
		$nama = $this->input->post('nama');

		if ($this->input->post('suhu') < 23.6) {
			$suhu = 'Rendah';
		} elseif ($this->input->post('suhu') < 27.2) {
			$suhu = 'Sedang';
		} else {
			$suhu = 'Tinggi';
		}

		if ($this->input->post('kadar_air') < 55) {
			$kadar_air = 'Rendah';
		} else {
			$kadar_air = 'Tinggi';
		}

		if ($this->input->post('curah_hujan') <= 20.7) {
			$curah_hujan = 'Rendah';
		} else {
			$curah_hujan = 'Tinggi';
		}

		if ($this->input->post('ph') <= 5.2) {
			$ph = 'Rendah';
		} elseif ($this->input->post('ph') < 6.6) {
			$ph = 'Sedang';
		} else {
			$ph = 'Tinggi';
		}

		if ($this->input->post('topografi') <= 500) {
			$topografi = 'Rendah';
		} elseif ($this->input->post('topografi') <= 1000) {
			$topografi = 'Sedang';
		} else {
			$topografi = 'Tinggi';
		}


		$hasil = $this->M_prediksi->Prediksi($kadar_air, $ph);
		if ($hasil == "Ciherang") {
			$hasil = 1;
		} elseif ($hasil == "IR64") {
			$hasil = 2;
		} elseif ($hasil == "Mekongga") {
			$hasil = 3;
		} else {
			$hasil = 4;
		}
		$data['varietas'] = $this->db->get_where('tb_varietas', ['id_var' => $hasil])->row_array();

		$data['title'] = 'Halaman Prediksi';
		$this->load->view('Templates/header', $data);
		$this->load->view('Auth/hasil_prediksi', $data);
		$this->load->view('Templates/footer');

		$data = array(
			'nama' => $this->input->post('nama'),
			'h_suhu' => $this->input->post('suhu'),
			'h_kadar_air' => $this->input->post('kadar_air'),
			'h_curah_hujan' => $this->input->post('curah_hujan'),
			'h_ph' => $this->input->post('ph'),
			'h_topografi' => $this->input->post('topografi'),
			'id_var' => $hasil
		);

		$this->db->insert('tb_histori', $data);
	}

	public function simpan_hasil()
	{
		// $data['title'] = 'Halaman Prediksi';
		// $this->load->view('Templates/header', $data);
		// $this->load->view('Auth/hasil_prediksi', $data);
		// $this->load->view('Templates/footer');

		$data = array(
			'nama' => $this->input->post('nama'),
			'h_suhu' => $this->input->post('suhu'),
			'h_kadar_air' => $this->input->post('kadar_air'),
			'h_curah_hujan' => $this->input->post('curah_hujan'),
			'h_ph' => $this->input->post('ph'),
			'h_topografi' => $this->input->post('topografi')
		);

		$this->db->insert('tb_histori', $data);
		redirect('Auth/hasil_prediksi');
	}

	public function histori()
	{
		$data['histori'] = $this->Model_dataset->ambil_histori();
		$data['nkategori'] = $this->db->get('tb_nilai_kategori')->result_array();
		$data['title'] = 'Halaman Histori';
		$this->load->view('Templates/header', $data);
		$this->load->view('Auth/histori', $data);
		$this->load->view('Templates/footer');
	}
}
